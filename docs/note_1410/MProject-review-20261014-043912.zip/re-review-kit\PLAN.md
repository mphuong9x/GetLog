# Kế hoạch review toàn MProject

## Mục tiêu và căn cứ

Ưu tiên: đúng nghiệp vụ và an toàn trạm sản xuất → phục hồi sau lỗi → bảo mật → nhất quán dữ liệu/trạng thái → khả năng quan sát → bảo trì → hiệu năng. Chỉ đề xuất thay đổi khi có lý do cụ thể.

Workspace có bộ review `00–11`, `IMPLEMENTATION_TASKS.md`, các evidence file và `PROJECT_STRUCTURE.json`. Dùng lại cấu trúc luồng và truy vết lịch sử; không sao chép finding cũ thành kết luận mới. Plan cũ được soạn từ snapshot trước và loại trừ một số payload/legacy; phạm vi đợt này mở rộng theo yêu cầu “tất cả project con”.

Các đường dẫn hướng dẫn cần kiểm tra sự tồn tại: `AGENTS.md` áp dụng theo thư mục, `MProjectFrontend/PROJECT_MEMORY.md`, `MProjectFrontend/PROJECT_REVIEW_CHECKLIST.md`. Một số prompt cũ dùng `docs/PROJECT_REVIEW_CHECKLIST.md`; tìm file thực tế trước khi đọc. File thiếu phải được ghi lại, không tự tạo nội dung giả định.

## Phạm vi bắt buộc

| Nhóm | Phạm vi |
| --- | --- |
| Backend | API, Application, Domain, Infrastructure, MProject.Tests, migrations, hosted services, cấu hình mẫu |
| Frontend | Toàn bộ source React/TypeScript, API client, cache, permissions, routing, workers, tests, build/lint config |
| Station runtime | MProjectAgent, MProjectLauncher, IPC contracts |
| Shared libraries | ProductionSupport.Contracts, TestResults và fixtures/corpus do dự án sở hữu |
| Verification | Agent.Tests, Agent.ServiceFixture, Agent.UpdateFixture, test helpers; kiểm tra test có thực sự bảo vệ contract |
| Installer và vận hành | MProjectAgent.Setup/Setup.cs, setup.manifest, scripts, root build/setup scripts, bundle version, CI |
| Legacy và payload | Old_program, Cpp_Software, Sample_Software: lập danh mục, review source do dự án sở hữu trong lượt L; đánh giá thêm contract với hệ thống hiện tại |
| Phần chưa nằm trong 00–10 | Repository/Git, Documents, TestAssets, tổ chức/người dùng và bất kỳ endpoint, worker, màn hình hay tool nào inventory phát hiện chưa có owner |

Không giới hạn theo `MProjectBackend/MProject.slnx`: solution đó không đại diện toàn bộ monorepo. Setup có thể được build từ script mà không có `.csproj`.

Không deep-review thư viện vendor, output build, binaries mẫu, `.git`, node_modules, bin/obj/dist/coverage. Ghi rõ từng nhóm loại trừ và lý do; vẫn kiểm tra dependency manifest, cấu hình đóng gói và nơi code sản phẩm tương tác với chúng. Source tự viết trong legacy/payload phải có trạng thái review; không âm thầm loại cả thư mục.

## Các lượt và thứ tự

Chạy `00` → `01–10` → `G` và `L` → `11`. Astra có thể điều chỉnh thứ tự sau khi lập dependency map, nhưng không bỏ phạm vi. Mỗi lượt tập trung một luồng xuyên project, có owner và ranh giới rõ.

| Lượt | Nội dung | Prompt cũ để tham khảo phạm vi |
| --- | --- | --- |
| 00 | Inventory thực tế, baseline, composition, contract ownership, coverage matrix | 00-architecture.md |
| 01 | Enrollment, Agent identity/token, heartbeat, command delivery, blob authorization | 01-agent-enrollment-and-control-plane.md |
| 02 | Assignment → job → Agent install/uninstall → ACK/watchdog/rollback | 02-station-deployment-job-lifecycle.md |
| 03 | Browser upload → TUS → Local/MinIO → immutable release → download/GC | 03-software-content-upload-and-blob-lifecycle.md |
| 04 | Config layering, overrides, baselines, approvals, render và redeploy | 04-config-overrides-baselines-and-approval.md |
| 05 | Setup/install/repair/uninstall, packaging/signing, OTA, version/ACL/recovery | 05-agent-release-and-self-update.md; mở rộng cho Setup và scripts hiện tại |
| 06 | Launcher, named-pipe IPC, session/privilege, process supervision | 06-launcher-ipc-and-process-supervision.md |
| 07 | Support workflow, SQLite outbox, retry/idempotency, recovery và UI | 07-production-support-durable-workflow.md |
| 08 | Parser, scan/cursors, ingestion/dedup, monitoring/query và UI | 08-test-result-ingestion-and-monitoring.md |
| 09 | User auth/refresh, RBAC/scope, approval engine, browser mutation contract | 09-identity-rbac-approvals-and-console-contract.md |
| 10 | Build/CI, deployment, IIS, PostgreSQL migrations/backup/restore, secrets config | 10-server-deployment-database-and-recovery.md |
| G | Review những domain/file chưa được bao phủ; chia G1/G2/... nếu lớn | Inventory hiện tại quyết định |
| L | Source legacy/native/sample; tách lỗi payload và lỗi tích hợp hệ thống | PROJECT_STRUCTURE.json + source hiện tại |
| 11 | Đối chiếu coverage, gộp root cause, quyết định ưu tiên và plan fix toàn đợt | 11-final-synthesis.md |

Prompt cũ nằm trong `docs/code-review/prompts/`. Chỉ dùng phần kỹ thuật/phạm vi còn phù hợp; đầu ra và delegation theo bộ mới. Với source hiện tại, đọc và trace độc lập trước, sau đó đối chiếu finding cũ để giảm thiên kiến.

## Đầu ra cho một run

Tạo `docs/code-review/runs/<YYYYMMDD-HHMMSS>-<shortHEAD>/`; nếu trùng thì thêm suffix. Lưu `RUN_DIR` trong checkpoint. Run là một lần review, không phải tên branch.

| File | Nội dung / người chịu trách nhiệm |
| --- | --- |
| SCOPE.md | HEAD, dirty state, baseline, môi trường, inventory, coverage theo project/file/luồng, exclusions và giới hạn; Astra chốt, Luna trình bày |
| raw/00-handoff.md, raw/01-handoff.md, ... | Hồ sơ kỹ thuật gốc tối thiểu do Astra ghi, đủ để tiếp tục sau mất context |
| raw/11-decisions.md | Canonical finding mapping, priority, fix direction, dependency và audit gates Astra đã chốt |
| reports/00-review.md, reports/01-review.md, ... | Báo cáo đọc được do Luna biên soạn; có trạng thái Astra đã/ chưa kiểm tra |
| FINDINGS.md | Danh sách finding có ID ổn định, bằng chứng và quyết định mới nhất |
| HISTORY-MAP.md | Finding/task cũ → finding mới hoặc kết quả revalidation có bằng chứng |
| FIX-PLAN.md | Task sửa theo root cause/ranh giới rollback, thứ tự, regression và nghiệm thu |
| PROGRESS.md | Bảng trạng thái, checklist review/fix/audit, checkpoint và việc tiếp theo |
| AUDIT.md | Kết quả audit tài liệu và audit từng bản sửa, revision, verdict, residual risk |
| evidence/ | Log đã che dữ liệu nhạy cảm, kết quả kiểm tra và probe tối thiểu nếu cần |

Không tạo báo cáo lượt chưa chạy như thể đã hoàn tất. Lượt 00 chỉ tạo danh mục, skeleton/tracker và hồ sơ của 00; plan fix còn là draft cho đến khi Astra chốt tổng hợp.

Baseline phải gồm HEAD và thay đổi chưa commit có liên quan, kể cả source cục bộ bị ignore/untracked. HEAD đơn lẻ không mô tả đủ working tree. Ghi manifest hash SHA-256 của source/prompt liên quan; không sao chép secret vào hồ sơ. Nếu baseline thay đổi giữa các lượt, ghi phần drift, đánh dấu phần ảnh hưởng cần revalidate, không ghép thành kết luận cùng snapshot.

Coverage dùng các mức `NOT_REVIEWED`, `PARTIAL`, `REVIEWED`, `BLOCKED`, `EXCLUDED_WITH_REASON`. Mỗi file tự viết có owning phase; `REVIEWED` cần mô tả cách kiểm tra/bằng chứng, không tính bằng việc file xuất hiện trong kết quả tìm kiếm. Mỗi luồng có entry point, producer/consumer, persistence, failure/recovery path và test tương ứng. Test coverage % không thay cho review coverage.

## Chuẩn finding và fix task

ID ví dụ `RR-03-001`; canonical merge phải giữ mọi source ID và alias, không renumber sau khi công bố.

Mỗi finding có: loại (confirmed defect / likely defect / design risk / maintainability / optional), P0–P3, confidence, project/flow, file + symbol + dòng tại snapshot, invariant bị vi phạm, preconditions, scenario, bằng chứng, impact thực tế, nguyên nhân, hướng sửa Astra chốt, test cần có và giới hạn xác minh. Phân biệt kết luận source-only, tái hiện bằng probe và runtime thật. Không suy ra “production đã bị ảnh hưởng” từ một test local.

P0: mất dữ liệu/kiểm soát nghiêm trọng cần chặn ngay; P1: sai nghiệp vụ, ngừng trạm hoặc hỏng recovery đáng kể; P2: ảnh hưởng có phạm vi/điều kiện hẹp; P3: tác động thấp. Xét xác suất và điều kiện khai thác; priority không đồng nghĩa confidence. Risk chưa chứng minh phải là verification task trước khi trở thành fix task.

Task sửa có `TASK-ID`, finding IDs, owner, model đề xuất, scope, invariant/acceptance criteria, dependencies, steps, regression test, provider/runtime gates, compatibility/migration, rollback, quyết định còn thiếu. Có thể nhiều task cho một finding hoặc một task cho nhiều finding; mapping phải đầy đủ.

Mọi finding phải có disposition: FIX, VERIFY_FIRST, ACCEPTED_RISK, DEFERRED, REJECTED hoặc OPTIONAL. “Accepted” cần quyết định người có thẩm quyền và lý do, model không tự chấp nhận rủi ro. Lưu ý các quyết định chủ dự án đã ghi trong guidance hiện hành, ví dụ shared installer token cho managed provisioning; không tự đảo ngược quyết định đó thành lỗi. Vẫn review các lỗi xác thực/ủy quyền hoặc xử lý token khác.

## Checklist tiến độ

Trạng thái task: `OPEN → PLANNED → IN_PROGRESS → IMPLEMENTED → VERIFIED`; `REOPENED`, `BLOCKED`, `DEFERRED`, `ACCEPTED_RISK` là nhánh riêng. IMPLEMENTED nghĩa là code đã sửa; VERIFIED cần audit và đủ gates. Mọi chuyển trạng thái có ngày, người/model, revision và evidence. ACCEPTED_RISK/DEFERRED không tính là lỗi đã sửa.

Mẫu bảng trong PROGRESS.md:

| Task | Finding | Priority | Owner | Status | Dependency | Fix revision/PR | Test evidence | Audit verdict/revision | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

Checklist mỗi lượt review:

- [ ] Snapshot, phạm vi và owner được ghi rõ.
- [ ] Luồng thành công, lỗi, timeout/cancel, retry/duplicate, crash/restart được kiểm tra khi áp dụng.
- [ ] Contract giữa producer/consumer và nơi commit trạng thái được trace.
- [ ] Finding cũ trong phạm vi có revalidation hoặc ghi rõ chưa xác minh.
- [ ] Finding mới có bằng chứng; rejected suspicions và good decisions được giữ.
- [ ] Luna đã lập tài liệu, Astra đã kiểm tra fidelity (giữ đúng kết luận).
- [ ] Coverage, giới hạn và checkpoint được cập nhật.

Checklist mỗi task sửa, chỉ tick khi có evidence tương ứng:

- [ ] Invariant, scope và dependencies đã chốt.
- [ ] Lỗi được tái hiện trên baseline hoặc có giải thích giới hạn tái hiện.
- [ ] Fix bao phủ mọi caller/consumer liên quan.
- [ ] Regression phù hợp chứng minh fail trước/pass sau; lý do N/A nếu không áp dụng.
- [ ] Suite phần bị ảnh hưởng và provider/runtime gates phù hợp đã pass.
- [ ] Compatibility, migration, restart/recovery và rollback đã kiểm tra nếu áp dụng.
- [ ] Docs/runbook được cập nhật nếu hành vi đổi.
- [ ] Astra audit bản sửa, verdict PASS tại revision cụ thể; không còn gate bắt buộc thiếu.

Không tick trước ngày sửa chỉ vì plan đã liệt kê đủ bước. N/A cần lý do và reviewer, không dùng N/A để bỏ qua gate khó.

## Kiểm tra phù hợp với MProject

Lượt 00 phải kiểm tra toolchain và test config, rồi xác nhận command plan trước khi chạy. Các lệnh sau là điểm bắt đầu, không phải bằng chứng đã chạy:

```powershell
dotnet test MProjectBackend/MProject.Tests/MProject.Tests.csproj
dotnet test MProjectAgent.Tests/MProjectAgent.Tests.csproj
```

Trong `MProjectFrontend`: `yarn test --run`, `yarn lint`, `yarn build`, phù hợp với package.json hiện có. Kiểm tra dependency sẵn có và test nào cần PostgreSQL/OS riêng. Build/tests qua backend solution không đủ vì solution không chứa mọi project/test.

Các boundary cần gate tương ứng: Npgsql/PostgreSQL cho concurrency/transaction/migrations; Local và MinIO cho blob; TUS HTTP cho upload; Windows/named pipe/session/ACL/LocalSystem cho Agent/Launcher/Setup; IIS/TLS cho server deploy; React/API cho mutation và cache. In-memory/mock test không chứng minh provider/runtime thật.

Đọc các `scripts/test-*.ps1` trước khi chạy: một số có thể tạo service, thay IIS/DB hoặc cần admin. Chỉ chạy trong môi trường disposable theo authorization thực tế; review-only không cho phép deploy lên trạm thật. Nếu thiếu môi trường, tiếp tục source review, ghi BLOCKED gate và cách kiểm tra sau. Không giả pass và không đóng finding vì test chưa chạy.

## Tiêu chí hoàn tất

Review hoàn tất khi mọi phạm vi đã có trạng thái minh bạch; không có NOT_REVIEWED/PARTIAL bị giấu; mọi finding cũ đã được đối chiếu hoặc liệt kê giới hạn; finding mới có evidence; mapping và task dependencies đầy đủ; Luna không làm đổi kết luận và Astra đã audit hồ sơ. Nếu còn phạm vi BLOCKED/PARTIAL, verdict là REVIEW PARTIAL, không tuyên bố review toàn bộ đã xong.

Remediation hoàn tất khi mọi task bắt buộc đã VERIFIED hoặc có disposition được người có thẩm quyền duyệt; các gates triển khai cần thiết đã pass; không còn P0/P1 chưa có quyết định xử lý. Audit hồ sơ review không chứng minh code đã được sửa, và audit code local không đồng nghĩa đã đủ điều kiện triển khai trên fleet.
