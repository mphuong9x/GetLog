# Báo cáo Phase 01 — Enrollment, identity và control-plane

**Tác giả:** Luna. **Technical reviewer:** Astra. **Trạng thái:** PARTIAL; Phase 00 deliverable COMPLETE, Phase 02 IN_PROGRESS/PARTIAL, toàn run IN_PROGRESS. Combined Phase 00–02 document fidelity PASS per [AUDIT.md](../AUDIT.md); code audit PENDING. Không remediation/live DB/service/IIS/deployment change. HEAD d4a6a920756470bdbd7300bdabe1d3891e7a7dfe; dirty TusUploadHandler.cs giữ nguyên; drift=[].

## Scope và giới hạn

Đã trace enrollment/auth/token transition, command/blob capability, liveness/status; continuation thêm install/bootstrap/TLS source, AgentWorker, RuntimeStateStore, InventoryReporter, AgentController/ServerClient/interfaces, command models và EnrollmentTokenModal. Còn PostgreSQL/provider concurrency, HTTP/TLS/LocalSystem integration, broader API/interface/test coverage, generated migration snapshot, whole human RBAC/job-runtime consumers và cross-phase gates. Không phải security approval.

## Findings

### RR-01-001 — Credential writers have an unguarded stale-write window
Confirmed defect, P1, High source confidence. Scenario A SQLITE_INTERLEAVING_REPRODUCED bằng current AgentService/EF SQLite, hai DbContexts và SaveChangesInterceptor: stale auth trả old generation; DB giữ new identity; old pending token accepted, new token rejected. Scenario B PendingEnrollment-vs-revoke SOURCE_ONLY. Không phải PostgreSQL proof. AgentService.cs:328–399 enrollment, :660–704 pending promotion, :706–726 revoke; Agent không VersionedEntity và EF model có zero Agent concurrency tokens. Root cause: chỉ một phần writers tham gia advisory serialization. Impact có thể làm mất enrollment hoặc ghi đè revocation trong interleaving cụ thể; không có incident claim. FIX-01-001 PLANNED: DB-enforced lock/CAS protocol do Astra chọn sau Npgsql tests; test independent contexts/barriers cho revoke/enroll, enroll/promote, heartbeat/promote, duplicate enrollment. Probe command delivery stubbed do SQLite DateTimeOffset limitation; không mô phỏng advisory lock/multi-process.

### RR-01-002 — Lost ACK can repeat an already executed restart
Confirmed defect, P1, High, SOURCE_ONLY, FIX-01-002 PLANNED. Server redelivers unacked command (AgentCommandService.cs:82–100); Agent executes then ACKs and logs failed ACK (AgentCommandHandler.cs:38–66, :84–95); ProcessSupervisor.cs:457–499 may restart without command-ID dedup. A successful restart plus unknown/lost ACK can repeat on redelivery. Hướng: durable receipt/result keyed by ID + identity/generation, explicit interrupted state, bounded retention; không tuyên bố boolean tạo exactly-once external effects. Phase 06 process and Phase 08 reset semantics gates; no process-restart probe.

### RR-01-003 — Rendered whole-file override denied by blob authorization
Confirmed defect, P2, High, SYNTHETIC_INMEMORY_REPRODUCED + source trace, FIX-01-003 PLANNED. Producer resolves original B → active whole-file override O → rendered R; render records BaseSha256=O, while AgentBlobDownloadAuthorizer recognizes rendered bases matching B. Isolated EF InMemory authorizer probe: original=True, activeReplacement=True, renderedFromReplacement=False; direct-base positive control=True. Controller DownloadLocalBlob returns 410 Gone when authorization false by source (~line 150), not 403; no HTTP E2E. Impact: composite override artifact denied unless already cached/equal hash. Hướng: authorize exact effective artifact graph for job/computer, not blanket cache rows. PostgreSQL/storage tests and phases 02/03/04 remain.

### RR-01-004 — Automatic redirects may forward Agent credentials across origins
Design risk, P2, High platform behavior; deployment reachability unknown; PLATFORM_LOOPBACK_REPRODUCED + source config; VERIFY_FIRST / VERIFY-01-004 PLANNED. Program.cs:122–127 uses default redirect; ServerClient adds X-Agent-Token; origin parser validates initial origin only. Two ephemeral localhost ports/fake token show default HttpClient follows 302 and both listeners see fake header, final 200. Not ServerClient/Agent/TLS/IIS, no real credential. Risk depends on reachable cross-origin redirect. Enroll/announce body forwarding untested. Verify actual route/client behavior with fake credentials before selecting hardening.

## Historical and test evidence

AGT01-03 fixed_verified only for expired-command dedup/quota logic; no new finding/task and no run task becomes VERIFIED.

Phase 00 tests: 50. Phase 01 tests: 113 after documented retries (67 backend, 45 distinct Agent, 1 frontend); Phase 01 cumulative checkpoint 163. Phase 02 adds 251 (95 Agent,147 backend,9 frontend), current cumulative 414 disjoint cases. Probes excluded; not a full-suite claim. Initial build-lock, ACL, synthetic PFX, esbuild failures remain in raw/evidence. PostgreSQL config absent; gate OPEN/BLOCKED_ENVIRONMENT. No production DB secrets searched or DB touched.

See [raw Phase 01](../raw/01-handoff.md), [continuation](../raw/01-continuation.md), [SCOPE](../SCOPE.md), [FIX-PLAN](../FIX-PLAN.md). Full rollout/test contracts remain in raw source-of-truth.


## Latest checkpoint

Coverage 78 REVIEWED / 30 PARTIAL / 2,261 NOT_REVIEWED. Current phase ownership: 00=36, 01=37, 02=68, 03=76, 04=95, 05=77, 06=37, 07=137, 08=26, 09=133, 10=89, G=452, L=1,106. Phase 02 remains IN_PROGRESS/PARTIAL; its continued source review added no new finding beyond RR-02-001. Phase 02 focused tests are 251; cumulative run tally 414. Combined Phase 00–02 document fidelity PASS per [AUDIT.md](../AUDIT.md); code audit remains PENDING.
