# Phase 00 — technical handoff

Reviewer: primary Astra session, 2026-10-13. Status: architecture/inventory pass completed within the limits below; documentation awaiting Luna and primary review. Overall review remains IN_PROGRESS. No remediation authorized/executed by this review phase.

## Snapshot and scope

- RUN_DIR: `docs/code-review/runs/20261013-233113-d4a6a92`.
- HEAD: `d4a6a920756470bdbd7300bdabe1d3891e7a7dfe`.
- Existing dirty production file: `MProjectBackend/MProject.Api/Infrastructure/TusUploadHandler.cs`. Reviewed snapshot is the working tree, not pristine HEAD. Its SHA-256 is in `evidence/baseline-files.csv`.
- `docs/code-review/re-review-kit/` was already untracked at start. Run output is new.
- Root/applicable project AGENTS.md absent. Only discovered AGENTS.md is in `docs/Agent_Solutions`, outside modified/reviewed source scope. Current memory/checklist are under `MProjectFrontend/`, not `docs/PROJECT_REVIEW_CHECKLIST.md`.
- Scope uses all components from PLAN.md. Inventory contains 2,369 candidate source/config/documentation files, 509,316 lines, with 1,106 legacy/payload candidates still requiring ownership/vendor classification. This is enumeration, NOT code review coverage. Counts include lockfiles, generated designers and vendor candidates, not exclusively first-party production LOC.
- `evidence/inventory-summary.json` has project counts. `baseline-files.csv` is immutable source fingerprint; `coverage.csv` is progress data. Phase routing is provisional and must be refined as each flow is traced. `inventory-exclusions.json` records 69 generated/vendor/runtime directory exclusions. Binary/media files outside source-extension allowlist are not deep-reviewed; release references and packaging remain in scope.
- Initial broad AGENTS search hit access-denied runtime fixture directories under `.tmp`; rerun excluded generated `.tmp`/artifacts successfully. This does not hide a source-tree access failure.
- Phase order: 00, 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, G (split by uncovered domain), L (split by legacy application), 11. Deep internals in later phases remain NOT_REVIEWED/PARTIAL.

## Verified architecture and composition

- API/Application/Infrastructure/Domain target net8. API -> Application + Infrastructure + support contracts. Application -> Domain + support/test-result contracts. Infrastructure -> Application + Domain + test-result contracts. Domain -> pure TestResults library. There is no cycle demonstrated by project references.
- Agent net8 references IPC netstandard2.0, support net8 and test-result net8. Launcher net48 WPF references only IPC, not net8 Agent/support implementation. Shared IPC has no PackageReference; serializer-neutral DTO boundary is intentional.
- Agent/Launcher/IPC import `MProject.StationBundleVersion.props`, version 2.0.0.3. Contract protocol/API versions are independent of assembly version.
- Backend solution has six projects and excludes backend test project, Agent, Launcher and their fixtures/tests. A solution-only build/test cannot verify the shipping system.
- Setup is compiled by `scripts/build-agent-setup.ps1` using .NET Framework csc and `MProjectAgent.Setup/Setup.cs` + `setup.manifest`; no csproj is needed for it. Setup output must remain outside the exact OTA bundle.
- API composition: scoped AppDbContext -> IAppDbContext; Npgsql. Local storage if Storage:Provider=Local, otherwise MinIO singleton client + scoped provider. Production startup rejects AutoMigrate=true; startup seed is omitted for validation-only host.
- API hosted work: AgentRolloutReconciler; MinioBucketInitializer when relevant; TusTempCleanup; BlobGc; InstallationJobWatchdog; StationRollbackWatchdog; ComputerLivenessWatchdog; DomainEventDispatcher; ProductionSupportMetricsCollector; SupportNotificationCleanup. All except AgentRolloutReconciler use AddDeploymentHostedService(validationOnly). Scoped DB/storage dependencies are resolved from scopes by sweep services. Deeper transaction rules are for owning phases.
- Agent hosted work: CoordinatedUpdateWorker, AgentWorker, BootstrapShutdownService, ProductionSupportDeliveryWorker, IpcServer, LauncherBootstrapper. Singleton stores/services plus server HttpClient compose the station runtime. Coordinated OTA is additional compared with old map. Store initialization/recovery goes to 02/05/07.
- Browser main.tsx composes auth/theme; App.tsx owns QueryClient/router/access gates. axios client rewrites /api to /api/v1, injects tokens and serializes refresh. API serves SPA from wwwroot with reserved API/Agent/Git/health/metrics/swagger prefixes protected from fallback. Identity/cache isolation needs phase 09.
- `prepare-deploy.ps1` builds schema contract and API, freezes frontend install and embeds SPA in API artifact. `package-agent.ps1` publishes Agent win-x64 and builds Launcher using VS MSBuild, bundles required DLLs, creates manifest, optionally Setup. Exact package contents and installation effects remain phase 05/10.
- `.github/workflows` has frontend verify and secret scan; no backend/Agent build job observed. This is a coverage observation, not an invented production defect.
- Shared test source/corpus compiles into both backend and Agent suites. Existing contract tests do not boot complete production hosts.

## Evidence and environment

- Windows 10.0.18362 x64; .NET SDK 10.0.401 active, 8.0.421 also installed; net8 runtime available; Node 24.15.0; Yarn 1.22.22 via yarn.cmd; Python 3.14.2.
- `yarn --version` hit PowerShell execution-policy block for yarn.ps1; yarn.cmd works without modifying machine policy.
- First backend focused test build in default Debug output failed MSB3027/MSB3021 because existing API binaries are held by another process. User process was not stopped. Evidence: `00-maintenance-test.log`; no test verdict from that attempt.
- Retried with `--artifacts-path C:/Users/Administrator/Desktop/TESS/MProject/.tmp/re-review-20261013-build -p:NuGetAudit=false -p:RestoreIgnoreFailedSources=true` to isolate build output. Backend phase-00 filters (DeploymentMaintenanceTests, ProductionWatchdogConfigurationTests, ProductionSupportContractTests, ProductionSupportCompatibilityMatrixContractTests, TestResultParserCorpusContractTests): 30 PASS, 0 fail, 0 skipped. Evidence `00-backend-contracts.log` / `.trx`.
- Agent filters (StationBundleVersionContractTests, ProductionSupportApiContractTests, ProductionSupportCompatibilityMatrixContractTests, TestResultParserCorpusContractTests, IpcProtocolContractTests): 20 PASS, 0 fail, 0 skipped. Evidence `00-agent-contracts.log` / `.trx`.
- .NET 8 probe compiled exact shared enum/converter source with BCL only. `00-enum-probe/Probe.csproj`, `Program.cs`, `00-enum-probe.log`. Command: `dotnet run --project <RUN_DIR>/evidence/00-enum-probe/Probe.csproj --verbosity quiet`. Exit 0; observed invalid wire representations accepted as described below. This is a serializer-level reproduction, not HTTP E2E.
- No real DB/service/IIS/OTA deployment exercised. Backend PostgreSQL tests depend on explicit disposable env config; some use `return` when config missing (could look passed without provider verification). DbConstraintNameTests' configured DB path calls EnsureDeletedAsync; do not run against arbitrary existing env. Agent ServiceInstallerScmTests writes SCM even though its comment describes opt-in: exclude from routine unprivileged test selection until isolated runtime checks are intended. These are command-plan constraints, not yet canonical findings.

## Findings: technical decisions

### RR-00-001 — OTA reconciler bypasses deployment validation-only worker gate

- Type: confirmed defect. Priority P1; confidence High. Evidence level SOURCE_ONLY; no DB-write runtime reproduction yet. Disposition FIX. Owner 00, consumers 05 and 10.
- Locations: `MProjectBackend/MProject.Api/Program.cs:100` directly registers AgentRolloutReconciler with AddHostedService. `Infrastructure/DeploymentMaintenance.cs:43` returns validation-only admission when marker exists; `:70` keeps it blocked; `:129–132` gated helper omits workers. `Services/AgentRolloutReconciler.cs:9–14` calls ReconcileAsync after each 30-second tick. `MProject.Application/Services/Assets/AgentRolloutService.cs:770–820` changes attempts/targets/rollouts/baselines and commits twice in the transaction.
- Invariant: validation-only API may expose health probes but must not construct/start business writers while deployment owns exclusive recovery fence.
- Preconditions/scenario: maintenance marker present; validation API remains alive >=30 seconds (e.g. prolonged validation or failed deployment awaiting recovery); database reachable and rollout records eligible for deadline/lease/completion/catch-up changes. Worker runs despite no shared writer admission and can commit changes within the maintenance window.
- Impact: rollout/baseline state can change while deployer assumes all writers are fenced, weakening coherent DB/binary recovery. Do not claim an observed production outage, or that every short successful deployment reaches a tick.
- Root cause: new hosted worker bypasses the common deployment-aware registration path.
- Direction: register this worker with AddDeploymentHostedService using deploymentMaintenance.ValidationOnly; add a composition-level invariant covering every business hosted service, not only helper behavior.
- Tests: actual API service collection validation mode contains no business workers; normal mode includes reconciler exactly once. Disposable PostgreSQL + maintained host >30 seconds must leave expired lease/eligible rollout records unchanged; normal mode must perform expected reconciliation. Keep recovery fence while testing, assert read-only health remains available.
- Existing gap: `DeploymentMaintenanceTests.cs:71–79` tests a synthetic ForbiddenWorker/helper only and passes even though production registration is wrong. Current 30 passing tests do not disprove this finding.
- Fix scope Small; dependency coordinate phase 05/10 but registration correction itself needs no schema change. Rollback restores prior binary but must not be presented as safe to deploy with maintenance bug; validate recoverability before release.
- Proposed task FIX-00-001: apply gating + host-composition regression + isolated runtime gate. Status PLANNED; no code fix performed.

### RR-00-002 — Production JSON policy defeats strict support enum wire contract

- Type confirmed defect; priority P2; confidence High. Evidence SERIALIZER_REPRODUCED, HTTP behavior not yet exercised. Disposition FIX. History ARC00-01 -> still_present. Owner 00; endpoint/consumer verification phase 07.
- Locations: `MProjectBackend/MProject.Api/Program.cs` AddControllers/AddJsonOptions (broad JsonStringEnumConverter); `MProject.ProductionSupport.Contracts/ProductionSupportEnums.cs:5` type attributes; `StrictStringEnumConverter.cs:20–25`; `MProjectBackend/MProject.Tests/ProductionSupportContractTests.cs:27–36` uses default options for negatives.
- Invariant: support enum wire values must be exact, named, case-sensitive strings and reject numerics/unknowns/whitespace.
- Reproduction with actual shared code: type-level converter rejects 2 and "resolved" but accepts "2" and " Resolved "; production-style options accept all these and numeric 99 as undefined enum. Valid "Resolved" round-trips.
- Impact: invalid client payloads cross advertised versioned boundary and can diverge across clients. No authorization bypass or invalid state persistence is asserted here; check service validation in phase 07.
- Root cause: broad options converter supersedes type converter; type converter itself uses Enum.TryParse rather than exact-name membership. Tests do not use MVC options for negative checks.
- Direction: preserve strict support converters ahead of broad policy, reject non-exact names, check Agent support-client options and retain legacy enum compatibility outside this contract.
- Tests: create/update DTO model binding under actual MVC options; reject number, numeric string, wrong case, whitespace, unknown value for every support enum; check valid names; equivalent Agent parser tests; HTTP negative tests in phase 07.
- Scope Small/Medium; no schema change expected; rollout compatibility must be checked against existing client wire representations. Proposed task FIX-00-002, PLANNED, dependencies phase-07 caller analysis.

### RR-00-003 — Domain-event acknowledgement remains logging-only

- Type design risk, priority P3, confidence High for current logging semantics. Disposition VERIFY_FIRST (requirements decision), not a demonstrated missing delivery defect. History ARC00-03 / ARCH-001 -> still_present as documented limitation.
- Location `MProjectBackend/MProject.Application/Services/Common/DomainEventDispatcherService.cs:43–70`: reads pending, logs payload, sets ProcessedAt, saves; no handlers/delivery ack.
- Scenario/impact conditional: future/current integration incorrectly interprets ProcessedAt as delivered side effect. No caller requiring such delivery was proved in this phase.
- Direction: determine intended consumers; preserve logging-only semantics if intentional and name/document accordingly. Introduce durable delivery only with a concrete required consumer. Do not prescribe event bus/redesign.
- Task VERIFY-00-003: inventory consumers and obtain/locate authoritative semantics; acceptance is documented owner decision with evidence. If delivery is required, Astra must design a separate fix with crash/retry/idempotency gates. No automatic acceptance of risk.

### RR-00-004 — Shared support prose still describes obsolete current runtime/version

- Type maintainability issue; priority P3; confidence High. Disposition FIX. History ARC00-04 -> still_present.
- Locations `MProject.ProductionSupport.Contracts/COMPATIBILITY_CONTRACT.txt:39` says current Stage-0 Agent has base-only capabilities; `CONTRACT.txt:1` labels Agent API v1. Current Agent Program.cs wires support implementation/delivery; frozen route/contract tests require agent/v2 and production-support-agent-v2.
- Scenario: release/integration reviewer reads these files and misidentifies active capability scope/API version. No observed production misdeployment claimed.
- Direction: mark Stage-0 historical, state actual active composition/API version, retain independent deployment compatibility matrix v1 naming. Do not erase historical gate limits or claim rollout already accepted.
- Task DOC-00-004, PLANNED: align prose with current constants/composition and cross-link authoritative contract. Documentation diff + constants review sufficient; no new mirrored tests required for prose-only change. Small, no runtime rollback.

## Historical revalidation without a new defect

- ARC00-02 (IIS lifecycle): appears_fixed_needs_runtime. `scripts/install-server.ps1:227,229,255` sets AlwaysRunning, idleTimeout=0, preloadEnabled. Cold boot/recycle/idle evidence on effective IIS remains required in phase 10. Do not re-report old “installer never configures these” claim. Existing-site/update/local helper parity also belongs to phase 10.
- Old statements that support services are only stubs, Domain depends on Agent, net48 loads net8 support, or missing watchdog registrations were rejected by current composition.
- Current production startup actively rejects AutoMigrate=true, stronger than old report's “explicit override can migrate”; preserve current behavior.

## Good decisions / limits / next action

Preserve: shared managed provisioning policy; shared parser and fixture source; serializer-neutral IPC/netstandard boundary; scoped DB aliases and scope-per-sweep; separation of Agent persistent state from replaceable binary bundle; same-origin SPA; versioned deployment maintenance protocol; explicit production migration ownership.

Do not infer full service-start success from source registration or focused contract tests. DI lifetime audit was source-based; no full-host API/Agent smoke yet. Backend storage health vs readiness, multi-instance sweep behavior, real station binary compatibility, IIS effective settings, all rollout acceptance gates remain unverified here.

Luna instructions: render SCOPE, phase-00 report, FINDINGS, HISTORY-MAP, DRAFT FIX-PLAN, PROGRESS, AUDIT from these decisions only. Include four findings (P1=1/P2=1/P3=2; types confirmed=2/design risk=1/maintainability=1), four proposed tasks, no fixed items. Phase 00 documentation approval PENDING until primary audit. Do not create reports for future phases. Put later phases NOT_STARTED. Link baseline/coverage CSV rather than copying 2,369 rows into prose.

Next: primary audits Luna's phase-00 docs, then phase 01 enrollment/auth/control-plane. Keep raw evidence immutable; corrections via addendum.
