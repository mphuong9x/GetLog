# Báo cáo Phase 00 — Inventory, composition và architecture

**Tác giả:** Luna. **Technical reviewer:** primary Astra. **Document fidelity:** PASS theo raw/00-audit-addendum.md cho bốn findings/contracts. **Code audit:** PENDING. Phase 00 COMPLETE chỉ cho deliverable inventory/composition ban đầu trong giới hạn nêu dưới; toàn run IN_PROGRESS. Không sửa code.

## Snapshot và composition

HEAD d4a6a920756470bdbd7300bdabe1d3891e7a7dfe; dirty TusUploadHandler.cs giữ nguyên; drift=[] trên 2,369 baseline files. Inventory là 2,369 candidates/509,316 dòng, 1,106 legacy/payload candidates; không phải production LOC hay review coverage. Latest coverage 78 REVIEWED / 30 PARTIAL / 2,261 NOT_REVIEWED.

Backend API/Application/Infrastructure/Domain là .NET 8, references hướng vào trong; API dùng scoped AppDbContext/Npgsql. Agent net8; IPC netstandard2.0; Launcher net48 WPF chỉ tham chiếu IPC. Setup build bằng Framework csc, Setup.cs và manifest; phải ngoài OTA bundle. Browser composition ở main.tsx/App.tsx; axios đổi /api thành /api/v1. prepare-deploy builds schema/API và nhúng SPA; package-agent publishes Agent/Launcher và bundle. Production startup từ chối AutoMigrate=true. Composition không chứng minh full runtime.

## Findings

### RR-00-001 — OTA reconciler bypasses deployment validation-only worker gate
Confirmed defect, P1, High, SOURCE_ONLY, FIX-00-001 PLANNED. Program.cs:100 đăng ký AgentRolloutReconciler trực tiếp, ngoài DeploymentMaintenance helper gate (DeploymentMaintenance.cs:129–132); worker reconcile mỗi 30 giây và rollout service commits state. Nếu maintenance marker còn và validation host chạy ≥30s với eligible rollout/lease, DB có thể đổi khi deployer cho rằng writers đã fenced. Không khẳng định outage. Hướng: deployment-aware registration và composition invariant cho business workers. Acceptance: validation mode không có writers, normal mode đăng ký đúng một lần, disposable PostgreSQL host >30s không đổi eligible state, normal reconciliation/health vẫn hoạt động. Small, không schema; runtime phối hợp 05/10 nhưng không chặn registration fix.

### RR-00-002 — Production JSON policy defeats strict support enum wire contract
Confirmed defect, P2, High, SERIALIZER_REPRODUCED, FIX-00-002 PLANNED. Broad AddJsonOptions converter trong Program.cs supersedes type converter. Shared-code probe cho thấy numeric strings, whitespace/case variants và undefined numeric values được nhận dưới production-style options; valid named value round-trips. Chưa HTTP E2E; không khẳng định auth bypass/persisted state. Hướng: strict exact-name converter và Agent parser checks. Phase 07 caller compatibility trước rollout; không schema change dự kiến.

### RR-00-003 — Domain-event acknowledgement remains logging-only
Design risk, P3, High chỉ cho semantics quan sát được, SOURCE_ONLY, disposition VERIFY_FIRST; VERIFY-00-003 PLANNED. DomainEventDispatcherService.cs:43–70 đọc event, log, set ProcessedAt, save; consumer delivery requirement chưa xác minh. Impact chỉ conditional nếu consumer hiểu ProcessedAt là side effect đã giao. Inventory consumers và owner quyết định logging-only/delivery; không tự đề xuất event bus. Nếu delivery bắt buộc, Astra thiết kế contract riêng.

### RR-00-004 — Shared support prose describes obsolete runtime/version
Maintainability, P3, High, FIX / DOC-00-004 PLANNED. COMPATIBILITY_CONTRACT.txt:39 còn mô tả Stage-0 Agent base-only; CONTRACT.txt:1 là contract v1 đóng băng cho work package 0A. Composition hiện tại có support delivery với các contract/route support v2 và v3; các endpoint Agent khác vẫn có v1. Tài liệu cũ có thể khiến reviewer nhầm phạm vi capability/version đang hoạt động; không có misdeployment claim và không kết luận rollout gates đã được chấp nhận. Sửa prose để ghi rõ lịch sử Stage-0, composition và version theo từng route, giữ compatibility matrix độc lập. Prose-only.

## Evidence/limits

Backend focused filters 30 pass; Agent 20 pass. Serializer probe là BCL-level, không HTTP E2E. Initial build gặp locked output; retry dùng artifacts path riêng. Không chạy DB/service/IIS/OTA. Một số DB tests có thể return khi config thiếu; DbConstraintNameTests có EnsureDeleted; ServiceInstallerScmTests có thể chạm SCM, không chạy routine. Đây là command constraints, không finding.

Historical IIS ARC00-02 appears_fixed_needs_runtime: installer source đặt AlwaysRunning/idleTimeout/preload; effective settings thuộc Phase 10. Nghi ngờ về stubs, project dependencies, net48 load net8 và missing watchdog registrations bị bác theo composition. Production startup actively rejects AutoMigrate=true.

Xem [SCOPE.md](../SCOPE.md), [FINDINGS.md](../FINDINGS.md), [raw handoff](../raw/00-handoff.md), [audit addendum](../raw/00-audit-addendum.md).
