"""Record only explicitly examined coverage; check immutable baseline for drift."""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
coverage = list(csv.DictReader((HERE / 'coverage.csv').open(encoding='utf-8-sig', newline='')))
decisions = {}
def record(phase, status, names, reason):
    for name in names.splitlines():
        name = name.strip()
        if name:
            decisions[name] = (phase, status, reason)

record('00', 'REVIEWED', '''
MProjectBackend/MProject.Api/Infrastructure/DeploymentMaintenance.cs
MProjectBackend/MProject.Api/Services/AgentRolloutReconciler.cs
MProjectBackend/MProject.Application/Services/Common/DomainEventDispatcherService.cs
MProject.ProductionSupport.Contracts/ProductionSupportEnums.cs
MProject.ProductionSupport.Contracts/StrictStringEnumConverter.cs
MProject.ProductionSupport.Contracts/COMPATIBILITY_CONTRACT.txt
MProject.ProductionSupport.Contracts/CONTRACT.txt
MProject.StationBundleVersion.props
''', 'raw/00-handoff.md: full source/contract read; enum probe where applicable; runtime limits remain')
record('00', 'PARTIAL', '''
MProjectBackend/MProject.Api/Program.cs
MProjectBackend/MProject.Application/Services/Assets/AgentRolloutService.cs
MProjectAgent/Program.cs
MProjectBackend/MProject.Tests/DeploymentMaintenanceTests.cs
MProjectBackend/MProject.Tests/ProductionSupportContractTests.cs
scripts/install-server.ps1
scripts/prepare-deploy.ps1
scripts/package-agent.ps1
''', 'raw/00-handoff.md: composition/targeted symbols; deeper flow/runtime review outstanding')
record('01', 'REVIEWED', '''
MProjectBackend/MProject.Api/Authentication/AgentAuthenticationHandler.cs
MProjectBackend/MProject.Api/RateLimiting/AgentProvisioningRateLimiter.cs
MProjectBackend/MProject.Application/Services/Assets/AgentCommandService.cs
MProjectBackend/MProject.Application/Services/Assets/AgentBlobCapabilityService.cs
MProjectBackend/MProject.Application/Services/Assets/AgentBlobDownloadAuthorizer.cs
MProjectBackend/MProject.Application/Services/Assets/ComputerLivenessWatchdogService.cs
MProjectBackend/MProject.Domain/Entities/Assets/Agent.cs
MProjectBackend/MProject.Domain/Entities/Software/OverrideFile.cs
MProjectBackend/MProject.Domain/Entities/Software/RenderedConfigBlob.cs
MProjectBackend/MProject.Tests/AgentBlobAuthorizationTests.cs
MProjectAgent/Services/AgentTokenTransitionManager.cs
MProjectAgent/Services/AgentCommandHandler.cs
MProjectAgent/Services/ServerReachabilitySignal.cs
MProjectAgent/Storage/TokenStore.cs
MProjectAgent/Storage/InstallerTokenScrubber.cs
''', 'raw/01-handoff.md: full source read + caller trace; focused tests/probe where applicable; not a claim of runtime acceptance')
record('01', 'PARTIAL', '''
MProjectBackend/MProject.Api/Controllers/Assets/AgentController.cs
MProjectBackend/MProject.Application/Services/Assets/AgentService.cs
MProjectBackend/MProject.Application/Services/Software/InstallationJobService.cs
MProjectBackend/MProject.Application/Services/Software/ConfigRenderService.cs
MProjectBackend/MProject.Infrastructure/DBContext.cs
MProjectBackend/MProject.Tests/AgentServiceTests.cs
MProjectBackend/MProject.Tests/AgentCommandServiceTests.cs
MProjectAgent/Configuration/AgentOptions.cs
MProjectAgent/Commands/EnrollCommand.cs
MProjectAgent/Services/ServerClient.cs
MProjectAgent/Services/AgentWorker.cs
MProjectAgent/Services/AgentStatusProvider.cs
MProjectAgent/Services/ProcessSupervisor.cs
''', 'raw/01-handoff.md: selected credential/command/blob/liveness paths read; other paths or dependent runtime contracts remain')

record('01', 'REVIEWED', '''
MProjectBackend/MProject.Api/Controllers/Assets/AgentController.cs
MProjectBackend/MProject.Api/Authentication/AgentAuthenticationDefaults.cs
MProjectBackend/MProject.Application/Interface/Assets/IAgentService.cs
MProjectBackend/MProject.Application/Interface/Assets/IAgentCommandService.cs
MProjectBackend/MProject.Domain/Entities/Assets/AgentCommand.cs
MProjectBackend/MProject.Domain/Enums/AgentCommandType.cs
MProjectBackend/MProject.Domain/Options/ComputerLivenessOptions.cs
MProjectBackend/MProject.Tests/ComputerLivenessWatchdogServiceTests.cs
MProjectAgent/Services/AgentWorker.cs
MProjectAgent/Services/ServerClient.cs
MProjectAgent/Services/InventoryReporter.cs
MProjectAgent/Storage/RuntimeStateStore.cs
MProjectAgent.Tests/RuntimeStateStoreTests.cs
MProjectAgent.Tests/EnrollCommandOptionsTests.cs
MProjectAgent.Tests/AgentTlsTrustTests.cs
MProjectFrontend/src/pages/Computer/components/EnrollmentTokenModal.tsx
MProjectFrontend/src/pages/Computer/components/EnrollmentTokenModal.test.tsx
''', 'raw/01-continuation.md: source read/caller tracing and focused tests; remaining runtime gates explicit')
record('05', 'PARTIAL', '''
MProjectAgent/Commands/BootstrapCommand.cs
MProjectAgent/Commands/ServiceInstaller.cs
scripts/install-agent.ps1
MProjectAgent.Tests/ServiceInstallerBootstrapTests.cs
''', 'raw/01-continuation.md: enrollment/TLS/preflight source examined; full install/OTA/SCM phase05 remains')
record('10', 'PARTIAL', '''
MProjectBackend/MProject.Infrastructure/Migrations/20260610223302_AddAgentCommandQueue.cs
''', 'raw/01-continuation.md: queue table/index examined; migration-chain/runtime acceptance remains phase10')
record('02', 'PARTIAL', '''
MProjectAgent/Storage/JobJournalStore.cs
MProjectAgent/Services/JobExecutor.cs
''', 'raw/01-continuation.md: phase02 started journal-to-executor trace; conclusions not complete')
record('02', 'REVIEWED', '''
MProjectAgent/Storage/JobJournalStore.cs
MProjectAgent/Services/JobExecutor.cs
MProjectAgent/Services/JobCancellationRegistry.cs
MProjectAgent/Services/BlobCacheService.cs
MProjectAgent/Storage/CacheIndex.cs
MProjectAgent/Services/InstallDirectoryService.cs
MProjectAgent/Services/InstallDirGuard.cs
MProjectAgent/Services/InstallFileSystem.cs
MProjectAgent/Services/InstallDirScanner.cs
MProjectAgent/Services/InventoryReporter.cs
MProjectAgent/Services/LaunchPolicy.cs
MProjectAgent/Services/EntryPointCommandBuilder.cs
MProjectAgent/Storage/AppCatalogStore.cs
MProjectBackend/MProject.Application/Services/Software/InstallationJobWatchdogService.cs
MProjectBackend/MProject.Application/Services/Software/StationRollbackWatchdogService.cs
MProjectBackend/MProject.Application/Services/Software/StationSoftwareAssignmentService.cs
MProjectBackend/MProject.Application/Services/Software/PcInstallationService.cs
MProjectBackend/MProject.Application/Services/Software/PcInventoryService.cs
MProjectBackend/MProject.Api/Controllers/Software/SoftwareAssignmentsController.cs
MProjectBackend/MProject.Api/Controllers/Software/PcInstallationsController.cs
MProjectBackend/MProject.Tests/InstallationJobWatchdogServiceTests.cs
MProjectBackend/MProject.Tests/InstallationJobConcurrencyTests.cs
MProjectBackend/MProject.Tests/StationRollbackWatchdogServiceTests.cs
MProjectAgent.Tests/JobJournalRecoveryTests.cs
MProjectAgent.Tests/JobCancellationRegistryTests.cs
MProjectAgent.Tests/JobExecutorInstallRootTests.cs
MProjectAgent.Tests/ProcessSupervisorRecoveryTests.cs
MProjectAgent.Tests/InstallDirGuardTests.cs
MProjectAgent.Tests/InstallDirScannerTests.cs
MProjectAgent.Tests/AppCatalogStoreTests.cs
MProjectAgent.Tests/LaunchPolicyTests.cs
MProjectAgent.Tests/EntryPointCommandBuilderTests.cs
MProjectAgent.Tests/InventoryReporterTests.cs
MProjectAgent.Tests/UninstallCleanupTests.cs
MProjectAgent.Tests/JobCancellationBarrierE2ETests.cs
MProjectBackend/MProject.Tests/PcInventoryServiceTests.cs
MProjectBackend/MProject.Tests/PcInstallationServiceTests.cs
MProjectBackend/MProject.Tests/StationSoftwareAssignmentServiceTests.cs
MProjectFrontend/src/pages/Software/hooks/use-deployment-matrix.test.ts
MProjectFrontend/src/pages/Software/components/DeploymentViews.test.tsx
''', 'raw/02-handoff.md: source/call tracing and focused tests; provider scope documented')
record('02', 'PARTIAL', '''
MProjectBackend/MProject.Application/Services/Software/InstallationJobService.cs
MProjectAgent/Services/ProcessSupervisor.cs
MProjectAgent/Services/InteractiveProcessLauncher.cs
MProjectBackend/MProject.Tests/InstallationJobServiceTests.cs
MProjectAgent.Tests/JobCancellationBarrierE2ETests.cs
MProjectFrontend/src/pages/Software/DeploymentMatrix.tsx
MProjectFrontend/src/pages/Software/components/AssignPackageModal.tsx
MProjectFrontend/src/pages/Installation/InstallationJobs.tsx
MProjectFrontend/src/pages/Installation/hooks/use-installation-jobs-page.ts
''', 'raw/02-handoff.md: selected transitions/cancel/uninstall exercised; full source/cross-provider flows remain')

paths = {row['path'] for row in coverage}
missing = set(decisions) - paths
if missing:
    raise RuntimeError(f'Coverage paths not inventoried: {sorted(missing)}')
for row in coverage:
    if row['path'] in decisions:
        phase, status, evidence = decisions[row['path']]
        row.update(status=status, evidence=evidence)
        # Keep primary owner of cross-phase files; otherwise correct provisional mapping.
        if phase == '01' and row['path'].endswith(('OverrideFile.cs', 'RenderedConfigBlob.cs')):
            continue
        if row['path'].endswith(('InstallationJobService.cs', 'ConfigRenderService.cs', 'DBContext.cs', 'ProcessSupervisor.cs')):
            continue
        row['phase'] = phase
with (HERE / 'coverage.csv').open('w', encoding='utf-8', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(coverage[0]))
    writer.writeheader()
    writer.writerows(coverage)

baseline = list(csv.DictReader((HERE / 'baseline-files.csv').open(encoding='utf-8-sig', newline='')))
drift = []
for row in baseline:
    path = ROOT / row['path']
    digest = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else 'MISSING'
    if digest.lower() != row['sha256'].lower():
        drift.append({'path': row['path'], 'baseline_sha256': row['sha256'], 'current_sha256': digest})
summary = {'coverage': dict(Counter(row['status'] for row in coverage)),
           'phase_ownership': dict(sorted(Counter(row['phase'] for row in coverage).items())),
           'baseline_drift': drift,
           'limits': 'Allowlisted source snapshot only. New run docs/evidence intentionally outside baseline. REVIEWED means examined source, not fixed or runtime-verified.'}
(HERE / 'checkpoint-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
