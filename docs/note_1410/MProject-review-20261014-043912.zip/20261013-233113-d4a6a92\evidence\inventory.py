"""Read-only source inventory; writes only evidence in this review run."""
from pathlib import Path
import csv, hashlib, json, os, re, subprocess
from collections import Counter

ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).resolve().parent
ROOTS = [p for p in ROOT.iterdir() if p.is_dir() and
         (p.name.startswith('MProject') or p.name in
          ('scripts', '.github', 'Old_program', 'Cpp_Software', 'Sample_Software'))]
SKIP = {'.git', '.vs', 'bin', 'obj', 'node_modules', 'dist', 'coverage',
        'artifacts', '.tmp', '__pycache__', 'packages', 'TestResults', 'wwwroot'}
EXT = {'.cs', '.xaml', '.csproj', '.sln', '.slnx', '.props', '.targets', '.ps1',
       '.cmd', '.bat', '.ts', '.tsx', '.js', '.mjs', '.cjs', '.json', '.yml',
       '.yaml', '.sql', '.py', '.cpp', '.c', '.h', '.hpp', '.vcxproj', '.config',
       '.manifest', '.ini', '.toml', '.lock', '.html', '.css', '.md', '.resx',
       '.txt', '.vb', '.vbs', '.sh', '.tcl', '.vcproj'}

def phase(path):
    s = str(path).replace('\\', '/').lower()
    name = Path(s).name
    if s.startswith(('old_program/', 'cpp_software/', 'sample_software/')):
        return 'L'
    if name in ('program.cs', 'app.xaml.cs', 'main.tsx', 'app.tsx') or Path(s).suffix in ('.csproj', '.slnx', '.props'):
        return '00'
    if 'mprojectagent.setup/' in s or re.search(r'(ota|bootstrap|agentrelease|agent-release|agent-update|agent-setup|agent-managed|setup-agent|setup-managed|applyupdate|prepareupdate|agentupdat|updatejournal|updateadmission|updateruntime|updatefixture|serviceinstaller|install-agent|package-agent|sign-agent|repair-agent|releaseenvelope|coordinatedupdate)', s):
        return '05'
    if re.search(r'(productionsupport|production-support|supportoutbox|supportreport|supportupdate|supportpreview|supportui|/support/|supportrequests)', s):
        return '07'
    if re.search(r'(testresult|test-result|testlog|testmetric|testmonitor|test-monitor)', s) or s.startswith('mproject.testresults/'):
        return '08'
    if re.search(r'(ipc|processsupervisor|entrypointcommand|interactiveprocess|launchpolicy|launcher)', s):
        return '06'
    if re.search(r'(configvalue|configparameter|configbaseline|configrender|configtarget|configlayer|configoverride|overridefile|redeploy|configfile)', s):
        return '04'
    if re.search(r'(upload|tus|blob|softwarefile|softwareversion|softwarepackage|hashcache|sha256)', s):
        return '03'
    if re.search(r'(installationjob|jobexecutor|jobjournal|jobcancel|deployprogress|stationsoftware|stationrollback|installationrecord|installdir|appcatalog|inventoryreport|installation)', s):
        return '02'
    if re.search(r'(agentauth|agenttoken|tokenstore|agentworker|agentservice|agentcontroller|agentcommand|agentclient|serverclient|enroll|agentserverorigin|computerliveness|heartbeat)', s):
        return '01'
    if re.search(r'(auth|permission|role|approval|accessrule|accesscontrol|securitystate|refreshtoken)', s):
        return '09'
    if s.startswith(('scripts/', '.github/')) or re.search(r'(migration|dbcontext|dbseed|deployment|storage/|maintenance|database|watchdog)', s):
        return '10'
    return 'G'

files, excluded = [], []
for root in ROOTS:
    for directory, dirs, names in os.walk(root, followlinks=False):
        for name in list(dirs):
            p = Path(directory) / name
            if name in SKIP or p.is_symlink() or p.is_junction():
                excluded.append({'path': p.relative_to(ROOT).as_posix(), 'reason': 'generated/vendor/runtime directory or link'})
                dirs.remove(name)
        for name in names:
            p = Path(directory) / name
            if p.suffix.lower() in EXT or name in ('Makefile', 'CMakeLists.txt'):
                files.append(p)
files += [p for p in ROOT.iterdir() if p.is_file() and (p.suffix.lower() in EXT or p.name in ('.gitignore', '.gitleaks.toml'))]
files += list((ROOT / 'docs/code-review/re-review-kit').glob('*.md'))
files += list((ROOT / 'docs/code-review/prompts').glob('*.md'))
rows = []
for p in sorted(set(files)):
    rel = p.relative_to(ROOT).as_posix()
    try:
        data = p.read_bytes()
        rows.append({'path': rel, 'phase': phase(rel), 'status': 'NOT_REVIEWED',
                     'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                     'lines': len(data.splitlines()), 'evidence': '',
                     'classification': 'legacy ownership/vendor verification pending' if phase(rel) == 'L' else 'source/config/docs'})
    except OSError as e:
        rows.append({'path': rel, 'phase': phase(rel), 'status': 'BLOCKED',
                     'sha256': '', 'bytes': '', 'lines': '', 'evidence': type(e).__name__,
                     'classification': 'unreadable'})
with (OUT / 'baseline-files.csv').open('w', encoding='utf-8', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
with (OUT / 'coverage.csv').open('w', encoding='utf-8', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
(OUT / 'inventory-exclusions.json').write_text(json.dumps(excluded, ensure_ascii=False, indent=2), encoding='utf-8')
summary = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
           'files': len(rows), 'phase_counts_provisional': dict(Counter(r['phase'] for r in rows)),
           'project_counts': dict(Counter(r['path'].split('/')[0] for r in rows)),
           'source_lines': sum(r['lines'] for r in rows if isinstance(r['lines'], int)),
           'excluded_directories': len(excluded),
           'note': 'Phase assignments provisional. Enumeration/hash is not review. Legacy ownership must be classified.'}
(OUT / 'inventory-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
