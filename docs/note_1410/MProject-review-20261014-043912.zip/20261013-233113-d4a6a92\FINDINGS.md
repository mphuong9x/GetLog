# Findings tổng hợp

Nguồn kỹ thuật: [raw Phase 00](raw/00-handoff.md), [Phase 00 addendum](raw/00-audit-addendum.md), [raw Phase 01](raw/01-handoff.md), [Phase 01 continuation](raw/01-continuation.md), [raw Phase 02](raw/02-handoff.md). Reports 00–02 giữ technical summaries; raw là nguồn chi tiết. Không có remediation.

| ID | Type | Priority | Confidence/evidence | Disposition | Task/status |
|---|---|---:|---|---|---|
| RR-00-001 | confirmed defect | P1 | High / SOURCE_ONLY | FIX | FIX-00-001 PLANNED |
| RR-00-002 | confirmed defect | P2 | High / SERIALIZER_REPRODUCED | FIX | FIX-00-002 PLANNED |
| RR-00-003 | design risk | P3 | High về logging semantics / SOURCE_ONLY | VERIFY_FIRST | VERIFY-00-003 PLANNED |
| RR-00-004 | maintainability | P3 | High / source-composition | FIX | DOC-00-004 PLANNED |
| RR-01-001 | confirmed defect | P1 | High / Scenario A SQLITE_INTERLEAVING_REPRODUCED; B SOURCE_ONLY | FIX | FIX-01-001 PLANNED |
| RR-01-002 | confirmed defect | P1 | High / SOURCE_ONLY | FIX | FIX-01-002 PLANNED |
| RR-01-003 | confirmed defect | P2 | High / synthetic in-memory reproduction + source; 410 Gone by controller source, no HTTP E2E | FIX | FIX-01-003 PLANNED |
| RR-01-004 | design risk | P2 | High platform behavior, deployment reachability unknown / PLATFORM_LOOPBACK_REPRODUCED | VERIFY_FIRST | VERIFY-01-004 PLANNED |
| RR-02-001 | confirmed defect | P2 | High source confidence / SOURCE_ONLY | FIX | FIX-02-001 PLANNED |

Totals: 9 findings/tasks; P1=3, P2=4, P3=2; confirmed=6, design risk=2, maintainability=1; FIX=7, VERIFY_FIRST=2; accepted/deferred/rejected/optional=0. IMPLEMENTED=0, VERIFIED=0. Historical AGT01-03 closes only expired-command quota/dedup logic; it is not a run task.

## RR-02-001 — shared failure-report gap

Post-ACK install/update and uninstall paths call SafeReportFailureAsync and delete journal regardless of server acknowledgment (JobExecutor.cs:253–262, :339–346; helper :594–619 logs/swallow errors). Server binds callbacks to ExecutionId; after journal loss, poll can create E2 while server remains bound to E1, causing stale callback conflict and possible generic watchdog timeout.

Pre-ACK, initial manifest validation at JobExecutor.cs:115–124 occurs before ACK. EnsureTransition permits Pending→Downloading or Cancelled, not Pending→Failed (InstallationJobService.cs:1050–1060). Watchdog tracks Downloading/Installing only (:19–23). The failed report is rejected and swallowed, journal deleted, and a deterministic invalid job can recur on polls while still Pending. Latest source notes PollTickAsync loops poll/execute immediately for active jobs and per-job exceptions bypass interval delay: repeated report/poll traffic can hot-loop until server state changes. Do not claim a particular production incident.

Invariant: preserve durable outcome until server confirms terminal/idempotent outcome. Direction: durable terminal-report stage with original ExecutionId/error context; define safe pre-ACK terminal semantics; resume report-only; prevent hot-loop traffic; do not repeat unsafe process/file work. Keep Conflict/Gone semantics explicit. Astra decides encoding/compatibility.

Phase 02 remains PARTIAL; 251 focused tests, 414 cumulative disjoint cases. Remaining InstallationJobService breadth, UI detail, supervisor races, E2E/provider/runtime. Full evidence and acceptance in [reports/02-review.md](reports/02-review.md).
