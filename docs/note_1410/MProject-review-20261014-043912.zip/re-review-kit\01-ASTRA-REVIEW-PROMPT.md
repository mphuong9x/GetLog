# Prompt cho Astra: review và bàn giao Luna

Copy phần trong code block. Điền PHASE/RUN_DIR hoặc dùng giá trị khởi đầu.

```text
Bạn là technical reviewer chính cho MProject. Tôi muốn review lại tất cả
project con, phát hiện lỗi thực tế và lập plan fix có checklist/audit.
Bạn chịu trách nhiệm kết luận kỹ thuật; Luna chịu trách nhiệm biên soạn hồ sơ.

PHASE=00
RUN_DIR=NEW

Đọc docs/code-review/re-review-kit/PLAN.md và làm theo phạm vi, đầu ra,
thứ tự và tiêu chí hoàn tất trong đó. Nếu PHASE=ALL, thực hiện lần lượt
các phase với checkpoint; nếu PHASE cụ thể, hoàn tất phase đó.

1. Xác lập ngữ cảnh
- Đọc AGENTS.md thực sự áp dụng, PROJECT_STRUCTURE.json và guidance hiện có.
  Tìm đúng PROJECT_MEMORY/PROJECT_REVIEW_CHECKLIST, ghi rõ file bị thiếu.
- Kiểm tra HEAD, dirty/untracked/ignored source liên quan, baseline, toolchain.
  Giữ nguyên thay đổi của người dùng. Đọc local working tree, không mặc định
  code đang review bằng đúng HEAD. Dùng hash để nhận diện snapshot.
- RUN_DIR=NEW chỉ cho phase 00: tạo run duy nhất theo PLAN.md; trả đường dẫn.
  Khi tiếp tục, đọc SCOPE.md, PROGRESS.md và raw handoff liên quan trước.
- Phase 00: inventory mọi project/source, kể cả Setup không có csproj,
  shared libraries, fixtures, scripts/CI và legacy/native/sample source tự viết.
  Lập coverage matrix có owner cho từng file và luồng. Ghi exclusions/vendor.
  Phase 00 không thay thế review sâu các phase sau.
- Không dùng solution backend làm đại diện toàn dự án. Nếu source đổi so với
  baseline, ghi drift và phạm vi cần review lại trước khi tổng hợp.

2. Review phase hiện tại
- Dùng prompt tương ứng trong docs/code-review/prompts cho luồng 00–10,
  mở rộng theo source hiện tại và PLAN.md. Phạm vi/đầu ra của bộ mới có ưu tiên.
- Đọc code hiện tại độc lập trước khi đối chiếu báo cáo cũ. Trace end-to-end:
  UI/client -> auth/validation -> domain/service -> persistence/storage ->
  background/Agent/IPC -> ACK/recovery -> UI/observable outcome, khi áp dụng.
- Kiểm tra invariant, state transitions, concurrency, timeout/cancel,
  duplicate/retry, partial failure, crash/restart, version compatibility,
  authorization/scope và recovery tại đúng boundary.
- Đánh giá tests/fixtures: test có gọi implementation thật, assert kết quả
  nghiệp vụ, bao phủ caller và provider/runtime cần thiết hay chỉ mock happy path.
- Chỉ chạy checks/probe local phù hợp, sau khi đọc tác dụng của test/script.
  Không chạm DB, station, service/IIS đang dùng thật. Có thể viết probe cô lập
  trong run/evidence nếu cần để xác minh; không sửa code sản phẩm.
- Ghi command, environment, exit/result và giới hạn. Không suy luận pass từ
  source inspection, không suy luận production incident từ fixture local.
- Sau review độc lập, đối chiếu reports cũ, synthesis, IMPLEMENTATION_TASKS
  và evidence files trong phạm vi: still_present / fixed_verified /
  appears_fixed_needs_runtime / partially_fixed / regressed / no_longer_applies /
  insufficient_evidence. Mỗi trạng thái có bằng chứng hoặc gate còn thiếu.
- Tôn trọng quyết định nghiệp vụ đã được chủ dự án chấp nhận trong guidance
  hiện hành. Phân biệt defect, risk cần xác minh và cải tiến tùy chọn.
- Không cần tạo finding cho mỗi file. Không đưa lời khuyên chung chung,
  refactor lớn hoặc redesign nếu thiếu lỗi/rủi ro cụ thể làm căn cứ.

3. Chốt hồ sơ kỹ thuật, trước khi giao Luna
- Mỗi finding có ID ổn định, type/priority/confidence, file/symbol/line tại
  snapshot, invariant, preconditions, scenario, evidence, impact, root cause,
  hướng sửa, regression, provider/runtime gates, rollback và verification limits.
- Ghi good decisions, rejected suspicions và insufficient-evidence questions.
- Astra quyết định mọi merge, priority, dependency và acceptance criteria.
  Phase 11 phải chốt canonical mapping và fix task contracts; Luna chỉ trình bày.
- Lưu raw/<phase>-handoff.md đủ để khôi phục mà không dựa vào chat history.
  Đây là hồ sơ bằng chứng/kết luận ngắn, không phải yêu cầu ghi suy nghĩ nội bộ.
  Bao gồm scope, snapshot, coverage, finding records, historical mapping,
  task contracts đã chốt, test evidence, uncertainties và next action.
- Phase 11 lưu thêm raw/11-decisions.md. Mỗi finding có disposition,
  mọi task có dependency, scope, test/acceptance/rollback. Quyết định sản phẩm
  còn thiếu trở thành decision task, không để Luna tự chọn nghiệp vụ.

4. Bắt buộc dùng model thấp hơn để tạo tài liệu kết quả
- Sau khi chốt kỹ thuật của phase, spawn một subagent dùng gpt-6-luna,
  effort Medium nếu hỗ trợ, với context mới và nhiệm vụ docs-only có phạm vi rõ.
  Không để subagent mặc định kế thừa Astra. Không gọi thêm reviewer Astra
  song song chỉ để tăng số lượng agent.
- Chỉ truyền RUN_DIR, PHASE, danh sách raw handoff/decisions đã chốt,
  PLAN.md và 02-LUNA-DOCUMENTATION-PROMPT.md; chỉ định tập file được viết.
- Yêu cầu Luna tạo/cập nhật reports/<phase>-review.md, SCOPE.md, FINDINGS.md,
  HISTORY-MAP.md, FIX-PLAN.md, PROGRESS.md, AUDIT.md theo dữ liệu của phase.
  FIX-PLAN là draft trước phase 11, không bịa quyết định thiếu. Không tạo
  báo cáo phase chưa chạy. Không sửa raw, code, tests sản phẩm hay báo cáo cũ.
- Ghi model thực tế sử dụng nếu công cụ cho biết. Nếu gpt-6-luna không gọi
  được hoặc không được phép override model, không giả rằng đã delegate.
  Lưu raw handoff đầy đủ, đánh dấu DOCUMENTATION_PENDING và trả prompt
  chạy riêng với 02-LUNA-DOCUMENTATION-PROMPT.md. Người dùng chọn Luna
  trong ứng dụng cho bước đó; không tự dùng Astra để viết toàn bộ báo cáo dài.

5. Kiểm tra sản phẩm của Luna
- Astra kiểm tra đầy đủ source-to-canonical mapping, priority, uncertainty,
  evidence links, count, task coverage và dependency; đọc kỹ toàn bộ P0/P1
  và các task auth/concurrency/recovery/OTA/migration. Spot-check prose còn lại.
- Báo cáo không được nâng source-only thành reproduced/runtime-verified,
  không biến risk thành defect, không mark task IMPLEMENTED/VERIFIED khi
  mới review. Kiểm tra checklist đang trống đúng phần chưa có evidence.
- Nếu sai, gửi correction cụ thể cho Luna, kiểm tra lại phần sửa và ghi
  document audit verdict trong AUDIT.md. Không tự đổi technical decisions
  chỉ để làm tài liệu khớp; nếu cần đổi, cập nhật raw bằng record mới trước.
- Checkpoint phase đã làm, phase còn lại, baseline drift, blockers và next action.
  Không đánh dấu phase hoàn tất nếu hồ sơ chưa được kiểm tra. Phase có giới hạn
  phải ghi PARTIAL/BLOCKED theo phạm vi; vẫn hoàn thành phần không bị chặn.

Kết thúc với tiếng Việt: RUN_DIR, phase status, số finding theo priority/type,
giới hạn thực tế, Luna có được sử dụng hay đang pending, đường dẫn kết quả
và phase/việc tiếp theo. Đây là review; chưa thực hiện remediation/deployment.
```
