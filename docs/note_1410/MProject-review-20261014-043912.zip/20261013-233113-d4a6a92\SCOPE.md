# Phạm vi và snapshot

**Run:** 20261013-233113-d4a6a92 · **HEAD:** d4a6a920756470bdbd7300bdabe1d3891e7a7dfe  
**Overall:** IN_PROGRESS. Dirty working-tree file `MProjectBackend/MProject.Api/Infrastructure/TusUploadHandler.cs` được giữ nguyên. Không có remediation hoặc DB/service/IIS/deployment change.

Phase 00 COMPLETE cho deliverable inventory/composition ban đầu trong các source/runtime limits đã ghi; không phải review toàn repo. Phase 01 PARTIAL. Phase 02 IN_PROGRESS/PARTIAL. Phase 03–10, G, L, 11 NOT_STARTED. Phase 00 document fidelity PASS theo [raw addendum](raw/00-audit-addendum.md); combined-doc fidelity PASS theo [AUDIT.md](AUDIT.md); code audit PENDING.

## Coverage tại checkpoint

| Trạng thái | Files |
|---|---:|
| REVIEWED | 78 |
| PARTIAL | 30 |
| NOT_REVIEWED | 2,261 |
| **Tổng** | **2,369** |

REVIEWED nghĩa là source được xem với evidence reference; không có nghĩa fixed/runtime-accepted. Drift=[] trên baseline.

| Owner | 00 | 01 | 02 | 03 | 04 | 05 | 06 | 07 | 08 | 09 | 10 | G | L |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Files | 36 | 37 | 68 | 76 | 95 | 77 | 37 | 137 | 26 | 133 | 89 | 452 | 1,106 |

Đây là ownership refined; original inventory assignment ở [inventory-summary.json](evidence/inventory-summary.json). Inventory gốc liệt kê 2,369 candidate files/509,316 dòng, trong đó 1,106 legacy/payload candidates cần ownership/vendor classification. Enumeration không phải review coverage hay first-party LOC. 69 generated/vendor/runtime directories bị loại theo exclusions; binary/media ngoài source allowlist không deep-review. Xem [coverage.csv](evidence/coverage.csv), [baseline-files.csv](evidence/baseline-files.csv), [checkpoint](evidence/checkpoint-summary.json).

## Composition Phase 00

| Thành phần | Composition | Ranh giới |
|---|---|---|
| Backend API/Application/Infrastructure/Domain | .NET 8; references hướng vào trong; API dùng scoped AppDbContext/Npgsql | Không chứng minh runtime/provider behavior |
| Agent | .NET 8; IPC netstandard2.0; support/TestResults net8 | Store recovery/OTA thuộc phase owners |
| Launcher | net48 WPF, chỉ tham chiếu IPC | Windows session/process thuộc 06 |
| Setup | Framework csc, Setup.cs, setup.manifest; không cần csproj | Phải ngoài OTA bundle; 05 |
| Browser/API | main.tsx auth/theme; App.tsx router/access/QueryClient; axios đổi /api thành /api/v1 | Identity/cache thuộc 09 |
| Deploy/package | prepare-deploy build schema/API và nhúng SPA; package-agent publish Agent/Launcher/DLL/manifest/optional Setup | 05/10 |
| Solution/CI | Sáu backend projects; solution bỏ tests/Agent/Launcher; CI có frontend verify/secret scan | Coverage observation, không tự suy ra defect |

Agent/Launcher/IPC version 2.0.0.3 độc lập protocol/API. Production startup từ chối AutoMigrate=true. API storage Local nếu Provider=Local, nếu không MinIO. Chi tiết ở [reports/00-review.md](reports/00-review.md).

## Phase 01/02

Phase 01 trace enrollment/auth/token, command/blob, liveness/status và continuation source; vẫn còn provider/HTTP/TLS/LocalSystem, broader API/interface/test, migration snapshot, RBAC/job-runtime và cross-phase gates. RR-01-001 Scenario A có SQLite interleaving reproduction, B SOURCE_ONLY. RR-01-003 controller source trả 410 Gone; chưa HTTP E2E. PostgreSQL gate OPEN/BLOCKED_ENVIRONMENT.

Phase 02 trace journal/executor/cancellation/watchdogs/assignment rollback/cache/deploy, controller/service/UI sampling, Agent support và ProcessSupervisor sampling. Không có finding bổ sung ở các continuation paths. RR-02-001 gồm install/update, uninstall và pre-ACK Pending→Failed rejection. PollTickAsync lặp poll/execute ngay khi active jobs còn trong manifest; per-job catch không quay về interval delay, nên report thất bại có thể tạo hot loop traffic đến khi server state đổi. Acceptance phải ngăn hot loop. Còn full InstallationJobService transitions/mutations, UI detail, supervisor races, E2E/provider/runtime acceptance.

Phase 02 có 251 focused tests (95 Agent, 147 backend, 9 frontend); cumulative Phase 00–02 = 414 disjoint cases. Không phải full suite/provider/E2E. Environmental failures/retries được giữ trong raw/evidence.

Không có PostgreSQL config (`MPROJECT_TEST_POSTGRES_CS` absent; psql/docker unavailable theo read-only check). Không có live DB/station service/production root/IIS. Không tuyên bố security approval. Raw handoffs là nguồn technical detail.
