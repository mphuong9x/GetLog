# FIX-PLAN — DRAFT trước Phase 11

Chín task đều PLANNED; không task IMPLEMENTED/VERIFIED. Astra sở hữu technical implementation, verification và code audit; Luna chỉ documentation. Phase 00 document fidelity PASS có giới hạn; combined Phase 00–02 document fidelity PASS theo [AUDIT.md](AUDIT.md); code audit PENDING. Không tự chọn DB locking/schema hoặc redirect hardening.

| Task | Finding | Priority | Contract/dependency |
|---|---|---:|---|
| FIX-00-001 | RR-00-001 | P1 | Register reconciler qua deployment-aware ValidationOnly gate, thêm composition invariant. Registration fix không chờ runtime acceptance 05/10. |
| FIX-00-002 | RR-00-002 | P2 | Strict exact-name converters và Agent parser; Phase 07 caller compatibility trước rollout. |
| VERIFY-00-003 | RR-00-003 | P3 | Consumer inventory và authoritative logging-vs-delivery decision. |
| DOC-00-004 | RR-00-004 | P3 | Align support prose với current constants/composition; giữ historical limits. |
| FIX-01-001 | RR-01-001 | P1 | DB-enforced serialization/conditional update cho mọi credential writers; lock/CAS do Astra quyết sau PostgreSQL tests. |
| FIX-01-002 | RR-01-002 | P1 | Durable command receipt/result; interrupted state; không lặp completed disruptive side effect. |
| FIX-01-003 | RR-01-003 | P2 | Authorize exact effective artifact graph; provider/storage gates. |
| VERIFY-01-004 | RR-01-004 | P2 | Kiểm tra deployed redirect/client behavior với fake credentials; quyết định hardening sau verification. |
| FIX-02-001 | RR-02-001 | P2 | Durable failed-report stage, safe pre-ACK terminal contract, report-only retry, anti-hot-loop behavior. |

## Acceptance

**FIX-00-001**

- [ ] Validation host không khởi động business writers.
- [ ] Normal host đăng ký reconciler đúng một lần.
- [ ] Disposable PostgreSQL host >30 giây không đổi eligible rollout/expired lease.
- [ ] Normal reconciliation và read-only health hoạt động.

**FIX-00-002**

- [ ] MVC production options từ chối numeric, numeric string, wrong case, whitespace, unknown.
- [ ] Valid names round-trip; Agent parser có negative checks tương ứng.
- [ ] Phase 07 xác minh HTTP/caller compatibility.

**VERIFY-00-003**

- [ ] Consumer inventory có evidence.
- [ ] Owner quyết định logging-only hay delivery-complete.
- [ ] Chỉ khi delivery bắt buộc: thiết kế crash/retry/idempotency riêng.

**DOC-00-004**

- [ ] Diff khớp constants/composition.
- [ ] Giữ historical limits; không hàm ý rollout được chấp thuận.

**FIX-01-001**

- [ ] Disposable PostgreSQL, independent contexts/barriers cho revoke/enroll, enroll/promote, heartbeat/promote, duplicate enroll.
- [ ] Winner/loser rõ; revoke không để credential stale; generation mới coherent.
- [ ] Không deadlock với rollout lock ordering.

**FIX-01-002**

- [ ] Ép ACK loss và redelivery cùng ID.
- [ ] Restart giữa execution/receipt/ACK; thử cancel và token re-enrollment.
- [ ] Verify một completed side effect/result khi completion biết được.
- [ ] Dùng disposable process fixture; kiểm retention/upgrade qua bundle replacement.

**FIX-01-003**

- [ ] Test B only, O only, B+values, O+values.
- [ ] Cross-computer/path, expired/tampered/revoked/cancelled/deletion-claimed đều denied.
- [ ] PostgreSQL query và manifest→signed URL→Local/MinIO stream/hash.
- [ ] Không tạo blob reference/GC leak.

**VERIFY-01-004**

- [ ] Ghi redirect reachability/compatibility.
- [ ] Thử origins/status codes/auth header/announce-enroll body bằng fake credentials.
- [ ] Chỉ nếu risk confirmed, Astra chọn hardening.

**FIX-02-001**

- [ ] Pre-ACK manifest validation đạt terminal result; không lặp như Pending.
- [ ] Poll/report loop có backoff hoặc bounded retry để ngăn hot loop khi job còn active/Pending.
- [ ] Failed-report timeout trước commit giữ journal/original ExecutionId.
- [ ] Retry giữ failure details; commit-success/lost-response idempotent.
- [ ] Conflict/Gone chỉ retire khi execution superseded/terminal đã được xác nhận.
- [ ] Restart resume report-only; watchdog/cancel races không tạo stale terminal conflict.
- [ ] Journal version/retention tương thích; fault-injection/provider HTTP contract.

FIX-02-001 scope small/medium: local journal stage và response classification. Không dự kiến schema change ban đầu; server terminal contract chi phối. Binary rollback cũ có thể quên stage; rollout phải giữ backward-compatible journal reader. FIX-PLAN vẫn DRAFT đến Phase 11.
