using System.Net;
using System.Net.Sockets;
using System.Text;
using Microsoft.EntityFrameworkCore;
using MProject.Application.Interface;
using MProject.Application.Services.Assets;
using MProject.Domain.Entities;
using MProject.Domain.Entities.Assets;
using MProject.Domain.Entities.Software;
using MProject.Domain.Entities.Identity;
using MProject.Domain.Enums;
using MProject.Infrastructure;

// Review-only synthetic state. No configured DB, real credentials or station services.
using var db = new AppDbContext(new DbContextOptionsBuilder<AppDbContext>()
    .UseInMemoryDatabase("review-" + Guid.NewGuid()).Options);
string Sha(char c) => new(c, 64);
Blob MakeBlob(char c) => new() { Sha256 = Sha(c), StoragePath = "review/" + c, Size = 1, ReferenceCount = 1 };
var original = MakeBlob('a');
var replacement = MakeBlob('b');
var rendered = MakeBlob('c');
var package = new SoftwarePackage { Name = "Synthetic review package" };
var version = new SoftwareVersion { SoftwarePackage = package, VersionNumber = "1", Status = SoftwareVersionStatus.Released };
var file = new SoftwareFile { SoftwareVersion = version, Blob = original, BlobSha256 = original.Sha256, RelativePath = "config.ini" };
var resource = new Resource { Type = "Computer", Name = "Synthetic review PC", Status = ResourceStatus.Active };
var computer = new Computer { Resource = resource, MacAddress = "00-11-22-33-44-55", Hostname = "synthetic-review" };
var agent = new Agent { Computer = computer, Status = AgentStatus.Active, TokenHash = "synthetic" };
var job = new InstallationJob { Computer = computer, SoftwareVersion = version, Status = InstallationJobStatus.Pending };
var replacementFile = new OverrideFile {
    Resource = resource, SoftwarePackage = package, TargetRelativePath = file.RelativePath,
    Blob = replacement, BlobSha256 = replacement.Sha256, FileName = file.RelativePath,
    Status = OverrideFileStatus.Active, Computer = computer
};
var cache = new RenderedConfigBlob { BaseSha256 = replacement.Sha256, ValueSetHash = Sha('d'),
    RenderedSha256 = rendered.Sha256, RenderedBlob = rendered };
db.AddRange(original, replacement, rendered, file, agent, job, replacementFile, cache);
await db.SaveChangesAsync();
var authorizer = new AgentBlobDownloadAuthorizer(db);
async Task<bool> Allowed(Blob b) => await authorizer.IsAuthorizedAsync(agent.Id,
    new AgentBlobCapability(agent.Id, job.Id, null, b.Sha256, b.StoragePath, DateTimeOffset.UtcNow.AddMinutes(1)));
var originalAllowed = await Allowed(original);
var replacementAllowed = await Allowed(replacement);
var renderedAllowed = await Allowed(rendered);
Console.WriteLine($"Actual authorizer, EF InMemory: original={originalAllowed}, activeReplacement={replacementAllowed}, renderedFromReplacement={renderedAllowed}");
if (!originalAllowed || !replacementAllowed || renderedAllowed) throw new Exception("Baseline behavior changed; revalidate finding.");
db.RenderedConfigBlobs.Add(new RenderedConfigBlob {
    BaseSha256 = original.Sha256, ValueSetHash = Sha('e'),
    RenderedSha256 = rendered.Sha256, RenderedBlob = rendered
});
await db.SaveChangesAsync();
var directRenderedAllowed = await Allowed(rendered);
Console.WriteLine($"Control: renderedFromOriginal={directRenderedAllowed}");
if (!directRenderedAllowed) throw new Exception("Positive control failed.");
var concurrency = db.Model.FindEntityType(typeof(Agent))!.GetProperties().Where(p => p.IsConcurrencyToken).Select(p => p.Name).ToArray();
Console.WriteLine($"Agent EF metadata concurrency tokens: {concurrency.Length}");

// Distinct loopback ports are distinct origins. Exercise platform HttpClient default,
// not the complete Agent host. Only a fixed fake credential is used.
using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(15));
using var origin = new TcpListener(IPAddress.Loopback, 0);
using var destination = new TcpListener(IPAddress.Loopback, 0);
origin.Start(); destination.Start();
int Port(TcpListener listener) => ((IPEndPoint)listener.LocalEndpoint).Port;
async Task<bool> Serve(TcpListener listener, string response)
{
    using var connection = await listener.AcceptTcpClientAsync(deadline.Token);
    using var stream = connection.GetStream();
    using var reader = new StreamReader(stream, Encoding.ASCII, false, leaveOpen: true);
    bool credentialSeen = false;
    while (await reader.ReadLineAsync(deadline.Token) is { Length: > 0 } line)
        credentialSeen |= line.StartsWith("X-Agent-Token: synthetic-review-token", StringComparison.OrdinalIgnoreCase);
    await stream.WriteAsync(Encoding.ASCII.GetBytes(response), deadline.Token);
    return credentialSeen;
}
var first = Serve(origin, $"HTTP/1.1 302 Found\r\nLocation: http://127.0.0.1:{Port(destination)}/sink\r\nContent-Length: 0\r\nConnection: close\r\n\r\n");
var second = Serve(destination, "HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n");
using var client = new HttpClient();
using var request = new HttpRequestMessage(HttpMethod.Get, $"http://127.0.0.1:{Port(origin)}/start");
request.Headers.Add("X-Agent-Token", "synthetic-review-token");
using var result = await client.SendAsync(request, deadline.Token);
Console.WriteLine($"Default HttpClient redirect probe: originSawSyntheticToken={await first}, crossOriginSawSyntheticToken={await second}, status={(int)result.StatusCode}");
Console.WriteLine("LIMITS: synthetic graph + EF InMemory; no real renderer/manifest/HTTP blob route, PostgreSQL race, TLS/IIS redirect or Agent host exercised.");
