# Báo cáo Phase 02 — Assignment, job lifecycle và recovery

**Tác giả:** Luna. **Technical reviewer:** Astra. **Trạng thái:** IN_PROGRESS/PARTIAL, checkpoint chứ chưa phase-complete. Phase 00 deliverable COMPLETE với limits; Phase 01 PARTIAL; Phase 03–10/G/L/11 NOT_STARTED. Overall IN_PROGRESS. Không remediation hoặc production/deployment change. HEAD d4a6a920756470bdbd7300bdabe1d3891e7a7dfe; dirty TusUploadHandler.cs giữ nguyên.

## Phạm vi đã trace

- StationSoftwareAssignmentService transactional cancel/reconcile: active jobs thành Cancelled; running jobs phát persisted CancelJob; uninstall intent gồm interrupted non-installed jobs; approved/reactivated assignment hủy stale uninstall work. Rollback rechecks assignment, target, previous target, pin timestamp và flap guard trong transaction.
- InstallationJobService.PollAsync chọn released/active versions, áp update window/running-app limits, tạo orphan uninstall theo policy, obey failure backoff, suppress duplicate active jobs; PostgreSQL unique violation trả canonical manifest. GetActiveJobs trả jobs sẵn có, không tự tạo job từ assignment.
- Server callbacks bind active Agent/Computer và ExecutionId. Ack chỉ Pending→Downloading; progress chỉ Downloading/Installing; completion transaction/idempotency cùng terminal status, stale/conflicting callback rejection, install/uninstall records/events/operational state. VersionedEntity concurrency bảo vệ stale writes.
- JobJournalStore per-job serialization, atomic temp+backup recovery. Executor journal trước ACK; ResumePending trước poll mới. Successful completion lost-response giữ Completing và retry cùng execution idempotent; cancellation barrier và watchdog version/status/cutoff checks được giữ.
- InstallDirectoryService validates manifest path/collisions, directory-chain leases, reparse rejection, sidecar+move và byte verification; cleanup best-effort. BlobCacheService verifies unknown/new bytes, eviction rechecks refcounts, deployment refs pin blobs. CacheIndex SQLite WAL, unique constraints, guarded refcount decrement, zero-ref eviction. Assignment rollback/watchdog kiểm tra pinned target/flap policy. Không có finding mới ở các paths; cross-process cache corruption/refcount crash recovery và PostgreSQL policy matrix chưa stress-test.
- Controllers SoftwareAssignmentsController/PcInstallationsController, PcInstallationService/PcInventoryService: permissions, Released-version/assignment checks, Agent-bound inventory, unknown/mismatched versions, auto-remove uninstall intent. UI DeploymentMatrix/AssignPackageModal/InstallationJobs và hook PARTIAL; assign/pin/activate/deactivate/remove/cancel/delete/refresh thấy được, hooks/table/detail/error contracts còn mở.
- Agent support InstallDirGuard/InstallFileSystem lexical+kernel no-reparse; InstallDirScanner imports bootstrap-root files; AppCatalogStore primary/backup JSON; LaunchPolicy/EntryPointCommandBuilder constrain launch. ProcessSupervisor sampled tại launch/stop/restart/recovery/health; mọi state transitions/races/platform tests còn mở.

## RR-02-001 — Failed report có thể làm mất durable job outcome

**Type/disposition:** confirmed defect, P2, High source confidence, SOURCE_ONLY, FIX. Owner Phase 02; FIX-02-001 PLANNED. Đây là một finding với hai scenario liên quan.

**Locations:** install/update JobExecutor.cs:253–262 và uninstall :339–346 catch local failure, gọi SafeReportFailureAsync rồi xóa journal dù chưa có server acknowledgment. Helper :594–619 catch report exceptions, log và return. Resume phụ thuộc journal :96–143, tái dùng stored ExecutionId :96–170. Server InstallationJobService.cs:489–520,1067–1087 bind callback vào persisted ExecutionId; stale execution bị reject. Watchdog InstallationJobWatchdogService.cs:57–125 xử lý in-flight no-progress (mặc định 30 phút, tối đa 180 phút, sweep 5 phút).

**Scenario A — lỗi sau ACK:** job active/ACKed; local artifact write/hash hoặc guarded deploy fail trước Completing. Failed report không được xác nhận/không commit. Helper nuốt lỗi, caller xóa journal. Server còn gắn E1; poll sau có thể tạo E2 và callback stale conflict. Watchdog có thể ghi generic timeout; retry phụ thuộc desired-state policy. Không khẳng định endless retry.

**Scenario B — manifest validation trước ACK:** ExecuteInstallJobAsync validate manifest :115–124 trước ACK. EnsureTransition :1050–1060 cho phép Pending→Downloading hoặc Cancelled, không Pending→Failed. Watchdog in-flight set :19–23 chỉ Downloading/Installing, không Pending. Failed report bị reject/swallow, journal bị xóa trong khi desired job còn Pending; poll sau có thể lặp deterministic validation failure.

**Hot-loop behavior:** AgentWorker.PollTickAsync tiếp tục poll/execute ngay khi manifest còn active jobs; per-job catch không quay về interval delay. Hai scenario có thể tạo repeated poll/report traffic, bao gồm hot loop, cho tới khi server state đổi. Poll cadence không phải backoff sau per-job exception. Acceptance cần bounded retry/backoff hoặc cơ chế tương đương; không tự chọn implementation.

**Invariant/impact/root cause:** durable local outcome phải retry được đến khi server xác nhận terminal/idempotent outcome. Mất failure detail gây chậm diagnosis/recovery; pre-ACK job có thể lặp mà watchdog không retire; post-ACK job có thể timeout generic. Không có production incident claim. Root cause gồm log-and-forget helper/unconditional journal deletion và server từ chối Pending→Failed dù Agent validate trước ACK.

**Direction:** giữ durable failure-report stage với original ExecutionId/status/error detail/duration cho đến terminal confirmation; định nghĩa pre-ACK terminal contract an toàn; resume report-only, không lặp unsafe file/process work. Phân loại auth/network/retryable/permanent; giữ semantics Conflict/Gone. Thêm anti-hot-loop behavior. Astra chọn encoding/compatibility; không schema change dự kiến ban đầu nhưng server contract chi phối.

**Acceptance/regression:**

- [ ] Pre-ACK manifest validation đạt terminal outcome và không lặp như Pending.
- [ ] Failed-report timeout trước commit giữ journal và original ExecutionId.
- [ ] Retry giữ failure detail; commit-success/lost-response idempotent.
- [ ] Conflict/Gone chỉ retire khi server xác nhận superseded/terminal.
- [ ] Restart resume report-only; watchdog/cancellation race không tạo stale terminal conflict.
- [ ] Poll/report lỗi không tạo hot loop; retry có bounded delay/backoff hoặc contract tương đương.
- [ ] Journal upgrade/retention backward-compatible; fault-injection/provider HTTP contract được test khi phù hợp.

Scope small/medium: local journal stage và response classification. Binary cũ có thể quên stage; rollout phải giữ backward-compatible reader. Chưa implementation.

## Evidence, tests và limits

Phase 02 tests: 251 (95 Agent,147 backend,9 frontend): job recovery Agent 21; Agent support 68; uninstall/cancel Agent 6; job/watchdog backend 80; inventory/installation backend 19; assignment backend 48; deployment matrix/views frontend 9. Cumulative Phase 00–02 = 414 disjoint focused cases. Chúng không inject lỗi vào SafeReportFailure, không tái tạo finding E2E, và không chứng minh provider/full-suite. PostgreSQL config absent (MPROJECT_TEST_POSTGRES_CS; psql/docker unavailable). Không DB/station/service/production root/IIS changed.

Historical JOB-001/JOB-002 là công việc hẹp trước đó về cancel/uninstall reconciliation và state machine/journal/concurrency; RR-02-001 là gap riêng. Conflict/Gone sau Completing không đồng nghĩa journal phải giữ vô điều kiện; stale progress sau cancel bị reject có chủ ý; execution-generation rejection cần được giữ.

## Checkpoint và phần còn mở

Coverage 78 REVIEWED / 30 PARTIAL / 2,261 NOT_REVIEWED; ownership 00=36,01=37,02=68,03=76,04=95,05=77,06=37,07=137,08=26,09=133,10=89,G=452,L=1,106; baseline drift=[]. Phase 02 IN_PROGRESS/PARTIAL. Còn full InstallationJobService transition/mutation, UI detail/hooks/table/error contract, ProcessSupervisor transitions/races, E2E, provider và runtime acceptance. Phase 01 PARTIAL. Combined Phase 00–02 document fidelity PASS per [AUDIT.md](../AUDIT.md); code audit remains PENDING. Không report phase tương lai.
