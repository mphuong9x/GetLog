using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using MProject.Application.Models;
using MProject.Application.Interface;
using MProject.Application.Services;
using MProject.Application.Services.Assets;
using MProject.Domain.Entities.Assets;
using MProject.Domain.Entities.Identity;
using MProject.Domain.Enums;
using MProject.Domain.Options;
using MProject.Infrastructure;

try
{
    await using var connection = new SqliteConnection("Data Source=:memory:");
    await connection.OpenAsync();
    var options = new DbContextOptionsBuilder<AppDbContext>().UseSqlite(connection).Options;
    AgentService Service(AppDbContext db)
    {
        var security = Options.Create(new AgentSecurityOptions { TokenPepper = Convert.ToBase64String(new byte[32]), TokenRotateAfterDays = 1 });
        return new AgentService(db, NullLogger<AgentService>.Instance,
            new EmptyCommandQueue(), security,
            new AgentBlobCapabilityService(security));
    }
    var actor = Guid.NewGuid();
    Guid computerId;
    string pendingCredential;
    string enrollmentTicket;
    Guid oldGeneration;
    await using (var setup = new AppDbContext(options))
    {
        await setup.Database.EnsureCreatedAsync();
        var resource = new Resource { Type = "Computer", Name = "Synthetic race PC", Code = "PC", Status = ResourceStatus.Active, CreatedBy = actor };
        var computer = new Computer { Resource = resource, Hostname = "synthetic-race", MacAddress = "00-11-22-33-44-66", CreatedBy = actor };
        setup.Computers.Add(computer);
        await setup.SaveChangesAsync();
        computerId = computer.Id;
        var service = Service(setup);
        var ticket = await service.GenerateEnrollmentTokenAsync(computerId, actor);
        var enrolled = await service.EnrollAsync(new AgentEnrollRequest { ComputerId = computerId, EnrollmentToken = ticket.EnrollmentToken });
        var agent = await setup.Agents.SingleAsync(x => x.Id == enrolled.AgentId);
        agent.TokenIssuedAt = DateTimeOffset.UtcNow.AddDays(-2);
        await setup.SaveChangesAsync();
        pendingCredential = (await service.RecordHeartbeatAsync(agent.Id, new AgentHeartbeatRequest())).RotatedAgentToken
            ?? throw new Exception("Synthetic setup did not issue a pending token.");
        oldGeneration = agent.IdentityGeneration;
        enrollmentTicket = (await service.GenerateEnrollmentTokenAsync(computerId, actor)).EnrollmentToken;
    }

    string? newCredential = null;
    Guid newGeneration = Guid.Empty;
    var barrier = new BeforeSaveBarrier(async () =>
    {
        // The first context already validated the pending token and mutated its tracked entity.
        // Complete a distinct re-enrollment before allowing that stale UPDATE to run.
        await using var newer = new AppDbContext(options);
        newCredential = (await Service(newer).EnrollAsync(new AgentEnrollRequest {
            ComputerId = computerId, EnrollmentToken = enrollmentTicket
        })).AgentToken;
        newGeneration = (await newer.Agents.AsNoTracking().SingleAsync()).IdentityGeneration;
    });
    var staleOptions = new DbContextOptionsBuilder<AppDbContext>().UseSqlite(connection).AddInterceptors(barrier).Options;
    await using (var stale = new AppDbContext(staleOptions))
    {
        var result = await Service(stale).AuthenticateAsync(pendingCredential);
        Console.WriteLine($"Stale authentication returned old generation: {result?.IdentityGeneration == oldGeneration}");
    }
    await using var verify = new AppDbContext(options);
    var final = await verify.Agents.AsNoTracking().SingleAsync();
    var oldAccepted = await Service(verify).AuthenticateAsync(pendingCredential) != null;
    verify.ChangeTracker.Clear();
    var newAccepted = await Service(verify).AuthenticateAsync(newCredential!) != null;
    Console.WriteLine($"Current SQLite/source reproduction: DB keeps new identity generation={final.IdentityGeneration == newGeneration}, old pending token accepted={oldAccepted}, newly enrolled token accepted={newAccepted}");
    if (newGeneration == oldGeneration || final.IdentityGeneration != newGeneration || !oldAccepted || newAccepted)
        throw new Exception("Expected stale promotion baseline not reproduced; revalidate.");
    Console.WriteLine("LIMITS: actual AgentService + EF SQLite, deterministic sequential interleaving at SaveChanges; command delivery stubbed to avoid unrelated SQLite DateTimeOffset translation. Not PostgreSQL advisory-lock/multi-process runtime. No production DB or credentials used.");
}
catch (Exception error)
{
    Console.Error.WriteLine(error);
    Environment.ExitCode = 1;
}

sealed class BeforeSaveBarrier(Func<Task> callback) : SaveChangesInterceptor
{
    private bool fired;
    public override async ValueTask<InterceptionResult<int>> SavingChangesAsync(DbContextEventData eventData, InterceptionResult<int> result, CancellationToken cancellationToken = default)
    {
        if (!fired) { fired = true; await callback(); }
        return result;
    }
}

sealed class EmptyCommandQueue : IAgentCommandService
{
    public Task<IReadOnlyList<AgentCommandDto>> ClaimPendingForDeliveryAsync(Guid computerId, DateTimeOffset now)
        => Task.FromResult<IReadOnlyList<AgentCommandDto>>(Array.Empty<AgentCommandDto>());
    public Task<AgentCommandDto> EnqueueAsync(Guid computerId, AgentCommandType type, string? payload, Guid? enqueuedBy)
        => throw new NotSupportedException("Not part of identity probe.");
    public Task AckAsync(Guid agentId, Guid commandId, string? result)
        => throw new NotSupportedException("Not part of identity probe.");
}
