# Phase 01 continuation — 2026-10-14

Supersedes the relevant evidence/status statements in raw/01-handoff.md. No production source changes. Primary continues technical work; Luna documents approved records only.

## Stronger current-snapshot evidence for RR-01-001

Created and ran evidence/01-identity-probe/ReviewIdentityProbe.csproj, exit0, final log evidence/01-identity-probe.log. Actual current AgentService and EF SQLite in-memory DB, separate DbContexts, SaveChangesInterceptor imposes this interleaving: old pending token has been checked -> a fresh enrollment completes -> old pending-token promotion saves. Output: stale auth returns old generation=True; DB retains new identity generation=True; old pending token accepted=True; newly enrolled token accepted=False. Assertions verify these exact outcomes. No real DB/credentials/station involved.

Evidence level for scenario A is now SQLITE_INTERLEAVING_REPRODUCED, replacing SOURCE_ONLY for that scenario. Scenario B (PendingEnrollment vs revoke) is still SOURCE_ONLY. The probe uses actual credential issuance/heartbeat/enrollment/authentication code; command delivery is stubbed to an empty queue because SQLite cannot translate the unrelated DateTimeOffset command queue query. It does not simulate that queue or PostgreSQL advisory locks/multi-process scheduling. Initial probe run encountered that SQLite translation limitation; the final harness isolates the identity path and records the stub explicitly. Do not call this a full PostgreSQL concurrency test or reuse historical SQLite logs. P1/type/confidence/direction/task unchanged.

Repro command: dotnet run --project docs/code-review/runs/20261013-233113-d4a6a92/evidence/01-identity-probe/ReviewIdentityProbe.csproj --artifacts-path C:/Users/Administrator/Desktop/TESS/MProject/.tmp/re-review-20261013-build -p:NuGetAudit=false -p:RestoreIgnoreFailedSources=true --verbosity quiet.

## Source correction for RR-01-003

AgentController.DownloadLocalBlob returns **410 Gone** when authorization is false (source line150), not 403 Forbidden. The initial handoff's 'forbidden route' wording was imprecise. The result is source trace + authorizer probe, not HTTP E2E. Luna was informed before final audit. No change to priority/root cause/task.

## Additional phase01 source tracing

- scripts/install-agent.ps1: strict origin validation; bundled public certificate checks SAN/EKU/time and compares self-signed fingerprint with remote public cert when available; permissive TLS callback is only for public-certificate comparison and sends no HTTP/token. A separate strict curl health probe must pass before stopping/removing service. Reject the suspicion that this inspection callback disables authenticated Agent TLS validation.
- Installer: lock down binary/config/state ACL before first elevated executable invocation; one-time token goes through hidden prompt/stdin, not arguments/config. validate-install preflight preserves protected OTA floor before reset/SCM changes. ResetEnrollment archives state and refuses overlapping install/state paths; deeper filesystem/reparse/SCM/OTA lifecycle belongs to phase05. No install script executed.
- BootstrapCommand/ServiceInstaller read: bootstrap outside replaced bundle, explicit child shutdown event, protected v2 floor validation before install, fail closed when floor missing/corrupt rather than fallback. Full recovery/OTA trust proof deferred phase05; no SCM mutations run.
- AgentWorker full orchestration: independent heartbeat/poll/inventory/test loops; startup retry; cancellation honored in loops; pending journals resumed before fresh poll; unrecoverable credentials logged for manual re-enrollment rather than reannounce. Commands remain inline heartbeat execution; downstream process/cancel races belong phase02/06. Telemetry failure is caught so heartbeat continues without support telemetry.
- RuntimeStateStore: primary/backup recovery, logged and metered invalid state, temp write + replacement; source and corruption/backup tests read. Consumer-specific stale process safety requires phase06; no physical power-loss proof.
- InventoryReporter: roots/relative paths/reparse guard before hashing, mismatch/missing/unreadable status, persists last-run marker after successful reporting. Server inventory reconciliation belongs phase02.
- Full AgentController, ServerClient and Agent interfaces/defaults/command model/enum inspected; controller ownership/auth boundaries maintained. AgentService runtime upsert/heartbeat operational-state preservation examined; test-results methods still phase08. Command migration table/index inspected; full chain and generated model snapshot phase10.
- EnrollmentTokenModal/test read: command includes ComputerId only, separate clipboard token, hidden installer prompt; no bearer in copied command. User permission/RBAC generating/revoking tickets still phase09.

## Additional tests

- evidence/01-agent-recovery-tls.*: filters InventoryReporterTests|RuntimeStateStoreTests|DefaultHttpHandler_RejectsUntrustedCertificateBeforeSendingToken. First run:13pass/2fail/0skip. Both failures are CryptographicException creating synthetic PFX user key inside sandbox, before HTTP. Exact two negative TLS cases retried with auto-review-approved escalation:2pass/0fail/0skip in evidence/01-agent-tls-runtime.*. No root certificate installed, no real server private key used, only synthetic certificate and loopback. One untrusted cert is expired too; this does not independently prove expiry validation of an otherwise trusted chain. Trusted-station certificate/wrong-host positive fixture deliberately not run on an existing machine private key.
- evidence/01-backend-liveness.*: ComputerLivenessWatchdogServiceTests 7pass/0fail/0skip; InMemory tests do not establish Npgsql conditional-update races. Test named Sweep_DoesNotBumpComputerVersion only asserts >=; do not claim it verifies unchanged Version.
- evidence/01-frontend-enrollment.log: first Vitest launch failed to load config because esbuild sandbox parent-directory read was denied. Same one-file test retried with approved escalation:1file/1test passed in evidence/01-frontend-enrollment-runtime.log. jsdom/mock clipboard only. No product-source/config change to force success.
- Phase01 now67backend +45distinctAgent +1frontend=113 passing cases after environmental retries. Phase00 contributes50 -> cumulative163, excluding probes from test-case count. Original build lock/ACL/key-store/esbuild failures remain disclosed. No full-suite claim.
- MPROJECT_TEST_POSTGRES_CS is absent; psql/docker not found on PATH in read-only check. We did not search production config for DB secrets or touch an existing DB. Disposable PostgreSQL concurrency gate unavailable in this environment as currently configured; continue source/isolated probes, keep that gate OPEN/BLOCKED_ENVIRONMENT rather than claim pass.

## Checkpoint and remaining scope

Phase01 remains PARTIAL because provider/HTTP/TLS/LocalSystem integration and broader cross-phase source/model/test coverage remain. The previous list saying provisioning/heartbeat/InventoryReporter/RuntimeStateStore had not been traced is superseded by the completed work above. Relevant large files/tests still PARTIAL in CSV; generated migration snapshot/whole human RBAC/whole job-runtime consumers were not silently reviewed. No new findings from this continuation; totals remain8 findings/8 PLANNED tasks (P1=3/P2=3/P3=2).

The principal phase01 producer/consumer boundaries and all five historical findings have revalidation dispositions. Begin phase02 source review while phase01 runtime gates remain explicit: journal store read and executor/server job entry points traced; no phase02 finding/report conclusion yet. Phase02 IN_PROGRESS, phases03–10/G/L/11 NOT_STARTED. Cross-phase consumer source coverage will be filled as its owning phase proceeds; this is a dependency-aware continuation, not declaring phase01 done.

Coverage and baseline drift after this continuation are in regenerated evidence/checkpoint-summary.json (use its actual counts). New evidence/doc files intentionally outside original source manifest. No task IMPLEMENTED/VERIFIED, no deployment.

## Documentation audit corrections for Luna

Preserve raw00 and raw01 histories, incorporate this addendum everywhere latest evidence/counts/status is summarized. Report01/task001 must distinguish reproduced scenario A from source-only B, SQL provider limits, stub and no real secrets. Report01/task003 must explicitly say410 source-only status. Existing combined-doc draft has regressed into inline '[ ]' in phase00 FIX-PLAN and phase01 report acceptance paragraphs: replace all such checklist text with real standalone Markdown '- [ ]' lines. Phase00 task paragraphs must use Vietnamese prose like the rest, preserve code terms. Put blank lines before checklist lists. Avoid duplicated command/result paragraphs in report01; keep one clear result section and links. Final combined-doc audit PENDING until primary checks corrected version. Phase00 fidelity PASS remains limited to its approved technical content, not code.
