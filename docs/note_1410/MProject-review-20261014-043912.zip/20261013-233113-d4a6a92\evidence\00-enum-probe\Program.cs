using System.Text.Json;
using System.Text.Json.Serialization;
using MProject.ProductionSupport.Contracts;

var strict = new JsonSerializerOptions(JsonSerializerDefaults.Web);
var api = new JsonSerializerOptions(JsonSerializerDefaults.Web);
api.Converters.Add(new JsonStringEnumConverter()); // API Program.cs production configuration.
var rows = new List<object>();
foreach (var (mode, options) in new[] { ("type-level-contract", strict), ("api-global-options", api) })
foreach (var input in new[] { "\"Resolved\"", "2", "\"resolved\"", "\"2\"", "\" Resolved \"", "99" })
{
    try
    {
        var result = JsonSerializer.Deserialize<ProductionSupportRequestStatus>(input, options);
        rows.Add(new { mode, input, accepted = true, value = result.ToString(), defined = Enum.IsDefined(result) });
    }
    catch (JsonException) { rows.Add(new { mode, input, accepted = false }); }
}
Console.WriteLine(JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));
