# MProject: review lại bằng Astra, lập hồ sơ bằng Luna

Ngày soạn: 2026-10-12. Đây là kế hoạch và prompt để chạy review sau này; chưa phải kết quả review code.

## Cách chạy

1. Chọn Astra trong ứng dụng. Gửi prompt ngắn dưới đây để chạy lượt `00`.
2. Khi `00` đã có bản đồ và danh sách lượt, chạy từng lượt với prompt đó, thay `PHASE` và dùng lại `RUN_DIR`. Mỗi lượt nên dùng cuộc hội thoại riêng, đọc hồ sơ bàn giao từ file.
3. Trong mỗi lượt, Astra chốt kết luận kỹ thuật rồi giao Luna tạo/cập nhật tài liệu. Nếu môi trường không hỗ trợ chọn model cho subagent, Astra lưu hồ sơ bàn giao; bạn chọn Luna và dùng `02-LUNA-DOCUMENTATION-PROMPT.md`.
4. Khi mọi lượt review hoàn tất hoặc có giới hạn được ghi rõ, chạy `PHASE=11` để Astra tổng hợp và Luna lập plan fix.
5. Sau này, sửa từng task theo plan. Dùng `03-ASTRA-AUDIT-PROMPT.md` để audit từng bản sửa và audit toàn đợt.

Prompt khởi động, có thể copy nguyên đoạn:

```text
Thực hiện kế hoạch review MProject trong docs/code-review/re-review-kit/PLAN.md.
Đọc và làm theo docs/code-review/re-review-kit/01-ASTRA-REVIEW-PROMPT.md.
PHASE=00; RUN_DIR=NEW.
Review tất cả project con theo coverage matrix, bao gồm code đang dùng,
tests, fixtures, Setup, scripts và code legacy do dự án sở hữu.
Bạn dùng Astra để review và chốt kết luận kỹ thuật. Sau mỗi lượt,
giao subagent gpt-6-luna biên soạn file kết quả, plan fix và checklist
từ hồ sơ bạn đã chốt; bạn kiểm tra lại hồ sơ Luna trước khi kết thúc lượt.
Nếu không gọi được Luna, lưu đủ hồ sơ bàn giao và nói rõ cách chạy bước Luna riêng.
Ở lượt này chỉ thực hiện phase 00, chưa sửa code sản phẩm.
```

Prompt tiếp tục một lượt:

```text
Đọc docs/code-review/re-review-kit/PLAN.md và
docs/code-review/re-review-kit/01-ASTRA-REVIEW-PROMPT.md.
RUN_DIR=<đường dẫn run đã tạo>; PHASE=<mã lượt tiếp theo trong SCOPE.md>.
Thực hiện trọn lượt này, bàn giao Luna lập tài liệu, kiểm tra tài liệu rồi
ghi checkpoint. Chưa sửa code sản phẩm. Không xem báo cáo cũ là bằng chứng hiện tại.
```

Thay nội dung trong `<...>` bằng giá trị thực. `RUN_DIR` do lượt `00` trả về.
Để chạy liên tục nhiều lượt, đặt `PHASE=ALL`; vẫn checkpoint và bàn giao theo từng lượt.

## Phân công model

| Công việc | Model đề xuất | Trách nhiệm |
| --- | --- | --- |
| Bản đồ, review luồng, xác minh finding | Astra / High nếu được hỗ trợ | Đọc code, đánh giá impact, kết luận kỹ thuật |
| Concurrency, crash recovery, OTA, auth, data integrity | Astra / Extra High hoặc Max nếu được hỗ trợ | Tăng effort tại ranh giới khó, không cần áp dụng cho mọi lượt |
| Báo cáo, bảng mapping, taskbook, checklist | Luna / Medium nếu được hỗ trợ | Chuyển hồ sơ đã chốt thành tài liệu có thể thực thi |
| Audit bản sửa và kết luận đóng lỗi | Astra | Kiểm tra độc lập với người sửa, quyết định VERIFIED/REOPENED |

Đây là cấu hình đề xuất, không phải cam kết về mức dùng hoặc giá. Chọn model/effort mà tài khoản và client thực tế hỗ trợ. Prompt yêu cầu delegate không tự đổi model của phiên chính.

Theo [official OpenAI documentation về subagents](https://learn.chatgpt.com/docs/agent-configuration/subagents), subagent có thể được yêu cầu model riêng; nếu không chỉ định thì thường kế thừa model/effort của agent cha. Vì vậy prompt ghi rõ `gpt-6-luna`, chỉ giao tác vụ tài liệu và có đường chạy riêng khi tính năng không khả dụng. Vai trò đề xuất cũng phù hợp với [hướng dẫn chọn model](https://developers.openai.com/api/docs/guides/model-selection): Astra cho phân tích khó, Luna cho công việc có phạm vi rõ.

## Các file trong bộ này

- `PLAN.md`: phạm vi, lượt review, đầu ra, checklist và tiêu chí hoàn tất.
- `01-ASTRA-REVIEW-PROMPT.md`: prompt review và bàn giao Luna.
- `02-LUNA-DOCUMENTATION-PROMPT.md`: prompt Luna chạy riêng hoặc dùng cho subagent.
- `03-ASTRA-AUDIT-PROMPT.md`: prompt audit bản sửa hoặc toàn đợt.

Báo cáo cũ trong `docs/code-review/reports/` và taskbook cũ được giữ làm lịch sử. Run mới không ghi đè các file đó. Các tài liệu chỉ có cục bộ cần được mang theo khi review ở clone hoặc máy khác.
