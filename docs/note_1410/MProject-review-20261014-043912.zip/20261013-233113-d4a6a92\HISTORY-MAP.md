﻿# HISTORY-MAP — traceability

## Phase 00

| Historical ID | Revalidation | Mapping | Evidence limit |
|---|---|---|---|
| ARC00-01 | still_present | RR-00-002 / FIX-00-002 | Serializer-level; chưa HTTP E2E. |
| ARC00-02 IIS lifecycle | appears_fixed_needs_runtime | Không finding mới; phase10 verification | Effective IIS cold boot/recycle/idle và parity còn mở. |
| ARC00-03 / ARCH-001 | still_present, logging-only limitation | RR-00-003 / VERIFY-00-003 | Chưa chứng minh consumer cần delivery. |
| ARC00-04 | still_present | RR-00-004 / DOC-00-004 | Prose cũ so với composition/version. |

## Phase 01

| Historical ID | Revalidation | Mapping | Evidence limit |
|---|---|---|---|
| AGT01-01 | still_present | RR-01-001 / FIX-01-001 | Scenario A current-service SQLite interleaving reproduced; Scenario B source-only; không phải PostgreSQL/multi-process. |
| AGT01-02 | still_present | RR-01-002 / FIX-01-002 | ACK/restart path source-traced; process restart fixture chưa chạy. |
| AGT01-03 | fixed_verified cho expired-command quota/dedup rule hẹp | Không finding/task mới | Current code và hai focused tests pass; không chứng minh concurrency-proof/fleet runtime, không VERIFIED task mới. |
| AGT01-04 | still_present, current authorizer synthetic repro | RR-01-003 / FIX-01-003 | Source controller response là 410 Gone; chưa HTTP/PostgreSQL E2E. |
| AGT01-05 | conditional; deployed reachability chưa rõ | RR-01-004 / VERIFY-01-004 | Loopback fake token; không observed leak/exploit fleet. |

Handoff Phase 00 bác các claim support stubs, Domain→Agent dependency, net48 loading net8 support, missing watchdog registration; production startup rejects AutoMigrate=true. Giữ nguyên các revalidation decisions. Phase 01 continuation không tạo finding mới; chỉ nâng evidence RR-01-001 scenario A và sửa source status RR-01-003 thành 410 Gone.

## Phase 02

| Historical item | Revalidation | Mapping | Giới hạn |
|---|---|---|---|
| JOB-001 (PROJECT_REVIEW_CHECKLIST) | COMPLETED Aug 2026; current cancellation/uninstall reconciliation controls remain | No new finding for completed behavior | RR-02-001 is narrower failed-report path, not reversal of completion. |
| JOB-002 (PROJECT_REVIEW_CHECKLIST) | COMPLETED Aug 2026; state machine/journal/concurrency controls remain | RR-02-001 / FIX-02-001 covers only pre-Completing Failed-report loss | Existing Conflict/Gone after Completing may retire journal by design; no unconditional retention claim. |

RR-02-001 is a new, narrower failure path: local error occurs before Completing and the Failed report is unconfirmed, then Agent deletes its journal. Preserve execution-generation rejection; do not drop it as a workaround. Good invariants from phase02 handoff remain in reports/02-review.md.
